var Bu={exports:{}},br={},Vu={exports:{}},T={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Yn=Symbol.for("react.element"),tc=Symbol.for("react.portal"),nc=Symbol.for("react.fragment"),rc=Symbol.for("react.strict_mode"),lc=Symbol.for("react.profiler"),oc=Symbol.for("react.provider"),ic=Symbol.for("react.context"),uc=Symbol.for("react.forward_ref"),ac=Symbol.for("react.suspense"),sc=Symbol.for("react.memo"),cc=Symbol.for("react.lazy"),Oi=Symbol.iterator;function fc(e){return e===null||typeof e!="object"?null:(e=Oi&&e[Oi]||e["@@iterator"],typeof e=="function"?e:null)}var Hu={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},Wu=Object.assign,Qu={};function rn(e,t,n){this.props=e,this.context=t,this.refs=Qu,this.updater=n||Hu}rn.prototype.isReactComponent={};rn.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")};rn.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function Ku(){}Ku.prototype=rn.prototype;function jo(e,t,n){this.props=e,this.context=t,this.refs=Qu,this.updater=n||Hu}var $o=jo.prototype=new Ku;$o.constructor=jo;Wu($o,rn.prototype);$o.isPureReactComponent=!0;var Di=Array.isArray,Yu=Object.prototype.hasOwnProperty,Uo={current:null},Xu={key:!0,ref:!0,__self:!0,__source:!0};function Gu(e,t,n){var r,l={},o=null,i=null;if(t!=null)for(r in t.ref!==void 0&&(i=t.ref),t.key!==void 0&&(o=""+t.key),t)Yu.call(t,r)&&!Xu.hasOwnProperty(r)&&(l[r]=t[r]);var u=arguments.length-2;if(u===1)l.children=n;else if(1<u){for(var a=Array(u),c=0;c<u;c++)a[c]=arguments[c+2];l.children=a}if(e&&e.defaultProps)for(r in u=e.defaultProps,u)l[r]===void 0&&(l[r]=u[r]);return{$$typeof:Yn,type:e,key:o,ref:i,props:l,_owner:Uo.current}}function dc(e,t){return{$$typeof:Yn,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}function Ao(e){return typeof e=="object"&&e!==null&&e.$$typeof===Yn}function pc(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var Mi=/\/+/g;function yl(e,t){return typeof e=="object"&&e!==null&&e.key!=null?pc(""+e.key):t.toString(36)}function gr(e,t,n,r,l){var o=typeof e;(o==="undefined"||o==="boolean")&&(e=null);var i=!1;if(e===null)i=!0;else switch(o){case"string":case"number":i=!0;break;case"object":switch(e.$$typeof){case Yn:case tc:i=!0}}if(i)return i=e,l=l(i),e=r===""?"."+yl(i,0):r,Di(l)?(n="",e!=null&&(n=e.replace(Mi,"$&/")+"/"),gr(l,t,n,"",function(c){return c})):l!=null&&(Ao(l)&&(l=dc(l,n+(!l.key||i&&i.key===l.key?"":(""+l.key).replace(Mi,"$&/")+"/")+e)),t.push(l)),1;if(i=0,r=r===""?".":r+":",Di(e))for(var u=0;u<e.length;u++){o=e[u];var a=r+yl(o,u);i+=gr(o,t,n,a,l)}else if(a=fc(e),typeof a=="function")for(e=a.call(e),u=0;!(o=e.next()).done;)o=o.value,a=r+yl(o,u++),i+=gr(o,t,n,a,l);else if(o==="object")throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.");return i}function er(e,t,n){if(e==null)return e;var r=[],l=0;return gr(e,r,"","",function(o){return t.call(n,o,l++)}),r}function mc(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(n){(e._status===0||e._status===-1)&&(e._status=1,e._result=n)},function(n){(e._status===0||e._status===-1)&&(e._status=2,e._result=n)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var ue={current:null},yr={transition:null},vc={ReactCurrentDispatcher:ue,ReactCurrentBatchConfig:yr,ReactCurrentOwner:Uo};function Zu(){throw Error("act(...) is not supported in production builds of React.")}T.Children={map:er,forEach:function(e,t,n){er(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return er(e,function(){t++}),t},toArray:function(e){return er(e,function(t){return t})||[]},only:function(e){if(!Ao(e))throw Error("React.Children.only expected to receive a single React element child.");return e}};T.Component=rn;T.Fragment=nc;T.Profiler=lc;T.PureComponent=jo;T.StrictMode=rc;T.Suspense=ac;T.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=vc;T.act=Zu;T.cloneElement=function(e,t,n){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var r=Wu({},e.props),l=e.key,o=e.ref,i=e._owner;if(t!=null){if(t.ref!==void 0&&(o=t.ref,i=Uo.current),t.key!==void 0&&(l=""+t.key),e.type&&e.type.defaultProps)var u=e.type.defaultProps;for(a in t)Yu.call(t,a)&&!Xu.hasOwnProperty(a)&&(r[a]=t[a]===void 0&&u!==void 0?u[a]:t[a])}var a=arguments.length-2;if(a===1)r.children=n;else if(1<a){u=Array(a);for(var c=0;c<a;c++)u[c]=arguments[c+2];r.children=u}return{$$typeof:Yn,type:e.type,key:l,ref:o,props:r,_owner:i}};T.createContext=function(e){return e={$$typeof:ic,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:oc,_context:e},e.Consumer=e};T.createElement=Gu;T.createFactory=function(e){var t=Gu.bind(null,e);return t.type=e,t};T.createRef=function(){return{current:null}};T.forwardRef=function(e){return{$$typeof:uc,render:e}};T.isValidElement=Ao;T.lazy=function(e){return{$$typeof:cc,_payload:{_status:-1,_result:e},_init:mc}};T.memo=function(e,t){return{$$typeof:sc,type:e,compare:t===void 0?null:t}};T.startTransition=function(e){var t=yr.transition;yr.transition={};try{e()}finally{yr.transition=t}};T.unstable_act=Zu;T.useCallback=function(e,t){return ue.current.useCallback(e,t)};T.useContext=function(e){return ue.current.useContext(e)};T.useDebugValue=function(){};T.useDeferredValue=function(e){return ue.current.useDeferredValue(e)};T.useEffect=function(e,t){return ue.current.useEffect(e,t)};T.useId=function(){return ue.current.useId()};T.useImperativeHandle=function(e,t,n){return ue.current.useImperativeHandle(e,t,n)};T.useInsertionEffect=function(e,t){return ue.current.useInsertionEffect(e,t)};T.useLayoutEffect=function(e,t){return ue.current.useLayoutEffect(e,t)};T.useMemo=function(e,t){return ue.current.useMemo(e,t)};T.useReducer=function(e,t,n){return ue.current.useReducer(e,t,n)};T.useRef=function(e){return ue.current.useRef(e)};T.useState=function(e){return ue.current.useState(e)};T.useSyncExternalStore=function(e,t,n){return ue.current.useSyncExternalStore(e,t,n)};T.useTransition=function(){return ue.current.useTransition()};T.version="18.3.1";Vu.exports=T;var Ju=Vu.exports;/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var hc=Ju,gc=Symbol.for("react.element"),yc=Symbol.for("react.fragment"),kc=Object.prototype.hasOwnProperty,wc=hc.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,xc={key:!0,ref:!0,__self:!0,__source:!0};function qu(e,t,n){var r,l={},o=null,i=null;n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),t.ref!==void 0&&(i=t.ref);for(r in t)kc.call(t,r)&&!xc.hasOwnProperty(r)&&(l[r]=t[r]);if(e&&e.defaultProps)for(r in t=e.defaultProps,t)l[r]===void 0&&(l[r]=t[r]);return{$$typeof:gc,type:e,key:o,ref:i,props:l,_owner:wc.current}}br.Fragment=yc;br.jsx=qu;br.jsxs=qu;Bu.exports=br;var Ld=Bu.exports,bu={exports:{}},ye={},ea={exports:{}},ta={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(e){function t(E,P){var N=E.length;E.push(P);e:for(;0<N;){var W=N-1>>>1,G=E[W];if(0<l(G,P))E[W]=P,E[N]=G,N=W;else break e}}function n(E){return E.length===0?null:E[0]}function r(E){if(E.length===0)return null;var P=E[0],N=E.pop();if(N!==P){E[0]=N;e:for(var W=0,G=E.length,qn=G>>>1;W<qn;){var vt=2*(W+1)-1,gl=E[vt],ht=vt+1,bn=E[ht];if(0>l(gl,N))ht<G&&0>l(bn,gl)?(E[W]=bn,E[ht]=N,W=ht):(E[W]=gl,E[vt]=N,W=vt);else if(ht<G&&0>l(bn,N))E[W]=bn,E[ht]=N,W=ht;else break e}}return P}function l(E,P){var N=E.sortIndex-P.sortIndex;return N!==0?N:E.id-P.id}if(typeof performance=="object"&&typeof performance.now=="function"){var o=performance;e.unstable_now=function(){return o.now()}}else{var i=Date,u=i.now();e.unstable_now=function(){return i.now()-u}}var a=[],c=[],v=1,m=null,p=3,y=!1,k=!1,w=!1,j=typeof setTimeout=="function"?setTimeout:null,f=typeof clearTimeout=="function"?clearTimeout:null,s=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function d(E){for(var P=n(c);P!==null;){if(P.callback===null)r(c);else if(P.startTime<=E)r(c),P.sortIndex=P.expirationTime,t(a,P);else break;P=n(c)}}function h(E){if(w=!1,d(E),!k)if(n(a)!==null)k=!0,vl(S);else{var P=n(c);P!==null&&hl(h,P.startTime-E)}}function S(E,P){k=!1,w&&(w=!1,f(z),z=-1),y=!0;var N=p;try{for(d(P),m=n(a);m!==null&&(!(m.expirationTime>P)||E&&!ze());){var W=m.callback;if(typeof W=="function"){m.callback=null,p=m.priorityLevel;var G=W(m.expirationTime<=P);P=e.unstable_now(),typeof G=="function"?m.callback=G:m===n(a)&&r(a),d(P)}else r(a);m=n(a)}if(m!==null)var qn=!0;else{var vt=n(c);vt!==null&&hl(h,vt.startTime-P),qn=!1}return qn}finally{m=null,p=N,y=!1}}var C=!1,_=null,z=-1,H=5,R=-1;function ze(){return!(e.unstable_now()-R<H)}function un(){if(_!==null){var E=e.unstable_now();R=E;var P=!0;try{P=_(!0,E)}finally{P?an():(C=!1,_=null)}}else C=!1}var an;if(typeof s=="function")an=function(){s(un)};else if(typeof MessageChannel<"u"){var Ri=new MessageChannel,ec=Ri.port2;Ri.port1.onmessage=un,an=function(){ec.postMessage(null)}}else an=function(){j(un,0)};function vl(E){_=E,C||(C=!0,an())}function hl(E,P){z=j(function(){E(e.unstable_now())},P)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(E){E.callback=null},e.unstable_continueExecution=function(){k||y||(k=!0,vl(S))},e.unstable_forceFrameRate=function(E){0>E||125<E?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):H=0<E?Math.floor(1e3/E):5},e.unstable_getCurrentPriorityLevel=function(){return p},e.unstable_getFirstCallbackNode=function(){return n(a)},e.unstable_next=function(E){switch(p){case 1:case 2:case 3:var P=3;break;default:P=p}var N=p;p=P;try{return E()}finally{p=N}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(E,P){switch(E){case 1:case 2:case 3:case 4:case 5:break;default:E=3}var N=p;p=E;try{return P()}finally{p=N}},e.unstable_scheduleCallback=function(E,P,N){var W=e.unstable_now();switch(typeof N=="object"&&N!==null?(N=N.delay,N=typeof N=="number"&&0<N?W+N:W):N=W,E){case 1:var G=-1;break;case 2:G=250;break;case 5:G=1073741823;break;case 4:G=1e4;break;default:G=5e3}return G=N+G,E={id:v++,callback:P,priorityLevel:E,startTime:N,expirationTime:G,sortIndex:-1},N>W?(E.sortIndex=N,t(c,E),n(a)===null&&E===n(c)&&(w?(f(z),z=-1):w=!0,hl(h,N-W))):(E.sortIndex=G,t(a,E),k||y||(k=!0,vl(S))),E},e.unstable_shouldYield=ze,e.unstable_wrapCallback=function(E){var P=p;return function(){var N=p;p=P;try{return E.apply(this,arguments)}finally{p=N}}}})(ta);ea.exports=ta;var Sc=ea.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Ec=Ju,ge=Sc;function g(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,n=1;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var na=new Set,Ln={};function Tt(e,t){Zt(e,t),Zt(e+"Capture",t)}function Zt(e,t){for(Ln[e]=t,e=0;e<t.length;e++)na.add(t[e])}var We=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Wl=Object.prototype.hasOwnProperty,Cc=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,Fi={},Ii={};function _c(e){return Wl.call(Ii,e)?!0:Wl.call(Fi,e)?!1:Cc.test(e)?Ii[e]=!0:(Fi[e]=!0,!1)}function zc(e,t,n,r){if(n!==null&&n.type===0)return!1;switch(typeof t){case"function":case"symbol":return!0;case"boolean":return r?!1:n!==null?!n.acceptsBooleans:(e=e.toLowerCase().slice(0,5),e!=="data-"&&e!=="aria-");default:return!1}}function Pc(e,t,n,r){if(t===null||typeof t>"u"||zc(e,t,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!t;case 4:return t===!1;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function ae(e,t,n,r,l,o,i){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=r,this.attributeNamespace=l,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=o,this.removeEmptyString=i}var ee={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){ee[e]=new ae(e,0,!1,e,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var t=e[0];ee[t]=new ae(t,1,!1,e[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(e){ee[e]=new ae(e,2,!1,e.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){ee[e]=new ae(e,2,!1,e,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){ee[e]=new ae(e,3,!1,e.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(e){ee[e]=new ae(e,3,!0,e,null,!1,!1)});["capture","download"].forEach(function(e){ee[e]=new ae(e,4,!1,e,null,!1,!1)});["cols","rows","size","span"].forEach(function(e){ee[e]=new ae(e,6,!1,e,null,!1,!1)});["rowSpan","start"].forEach(function(e){ee[e]=new ae(e,5,!1,e.toLowerCase(),null,!1,!1)});var Bo=/[\-:]([a-z])/g;function Vo(e){return e[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var t=e.replace(Bo,Vo);ee[t]=new ae(t,1,!1,e,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var t=e.replace(Bo,Vo);ee[t]=new ae(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(e){var t=e.replace(Bo,Vo);ee[t]=new ae(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(e){ee[e]=new ae(e,1,!1,e.toLowerCase(),null,!1,!1)});ee.xlinkHref=new ae("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(e){ee[e]=new ae(e,1,!1,e.toLowerCase(),null,!0,!0)});function Ho(e,t,n,r){var l=ee.hasOwnProperty(t)?ee[t]:null;(l!==null?l.type!==0:r||!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(Pc(t,n,l,r)&&(n=null),r||l===null?_c(t)&&(n===null?e.removeAttribute(t):e.setAttribute(t,""+n)):l.mustUseProperty?e[l.propertyName]=n===null?l.type===3?!1:"":n:(t=l.attributeName,r=l.attributeNamespace,n===null?e.removeAttribute(t):(l=l.type,n=l===3||l===4&&n===!0?"":""+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}var Xe=Ec.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,tr=Symbol.for("react.element"),Ot=Symbol.for("react.portal"),Dt=Symbol.for("react.fragment"),Wo=Symbol.for("react.strict_mode"),Ql=Symbol.for("react.profiler"),ra=Symbol.for("react.provider"),la=Symbol.for("react.context"),Qo=Symbol.for("react.forward_ref"),Kl=Symbol.for("react.suspense"),Yl=Symbol.for("react.suspense_list"),Ko=Symbol.for("react.memo"),Ze=Symbol.for("react.lazy"),oa=Symbol.for("react.offscreen"),ji=Symbol.iterator;function sn(e){return e===null||typeof e!="object"?null:(e=ji&&e[ji]||e["@@iterator"],typeof e=="function"?e:null)}var B=Object.assign,kl;function gn(e){if(kl===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);kl=t&&t[1]||""}return`
`+kl+e}var wl=!1;function xl(e,t){if(!e||wl)return"";wl=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t)if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(t,[])}catch(c){var r=c}Reflect.construct(e,[],t)}else{try{t.call()}catch(c){r=c}e.call(t.prototype)}else{try{throw Error()}catch(c){r=c}e()}}catch(c){if(c&&r&&typeof c.stack=="string"){for(var l=c.stack.split(`
`),o=r.stack.split(`
`),i=l.length-1,u=o.length-1;1<=i&&0<=u&&l[i]!==o[u];)u--;for(;1<=i&&0<=u;i--,u--)if(l[i]!==o[u]){if(i!==1||u!==1)do if(i--,u--,0>u||l[i]!==o[u]){var a=`
`+l[i].replace(" at new "," at ");return e.displayName&&a.includes("<anonymous>")&&(a=a.replace("<anonymous>",e.displayName)),a}while(1<=i&&0<=u);break}}}finally{wl=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:"")?gn(e):""}function Nc(e){switch(e.tag){case 5:return gn(e.type);case 16:return gn("Lazy");case 13:return gn("Suspense");case 19:return gn("SuspenseList");case 0:case 2:case 15:return e=xl(e.type,!1),e;case 11:return e=xl(e.type.render,!1),e;case 1:return e=xl(e.type,!0),e;default:return""}}function Xl(e){if(e==null)return null;if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Dt:return"Fragment";case Ot:return"Portal";case Ql:return"Profiler";case Wo:return"StrictMode";case Kl:return"Suspense";case Yl:return"SuspenseList"}if(typeof e=="object")switch(e.$$typeof){case la:return(e.displayName||"Context")+".Consumer";case ra:return(e._context.displayName||"Context")+".Provider";case Qo:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Ko:return t=e.displayName||null,t!==null?t:Xl(e.type)||"Memo";case Ze:t=e._payload,e=e._init;try{return Xl(e(t))}catch{}}return null}function Tc(e){var t=e.type;switch(e.tag){case 24:return"Cache";case 9:return(t.displayName||"Context")+".Consumer";case 10:return(t._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=t.render,e=e.displayName||e.name||"",t.displayName||(e!==""?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return t;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return Xl(t);case 8:return t===Wo?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t}return null}function ct(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function ia(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Lc(e){var t=ia(e)?"checked":"value",n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=""+e[t];if(!e.hasOwnProperty(t)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var l=n.get,o=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return l.call(this)},set:function(i){r=""+i,o.call(this,i)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(i){r=""+i},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function nr(e){e._valueTracker||(e._valueTracker=Lc(e))}function ua(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r="";return e&&(r=ia(e)?e.checked?"true":"false":e.value),e=r,e!==n?(t.setValue(e),!0):!1}function Tr(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function Gl(e,t){var n=t.checked;return B({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??e._wrapperState.initialChecked})}function $i(e,t){var n=t.defaultValue==null?"":t.defaultValue,r=t.checked!=null?t.checked:t.defaultChecked;n=ct(t.value!=null?t.value:n),e._wrapperState={initialChecked:r,initialValue:n,controlled:t.type==="checkbox"||t.type==="radio"?t.checked!=null:t.value!=null}}function aa(e,t){t=t.checked,t!=null&&Ho(e,"checked",t,!1)}function Zl(e,t){aa(e,t);var n=ct(t.value),r=t.type;if(n!=null)r==="number"?(n===0&&e.value===""||e.value!=n)&&(e.value=""+n):e.value!==""+n&&(e.value=""+n);else if(r==="submit"||r==="reset"){e.removeAttribute("value");return}t.hasOwnProperty("value")?Jl(e,t.type,n):t.hasOwnProperty("defaultValue")&&Jl(e,t.type,ct(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function Ui(e,t,n){if(t.hasOwnProperty("value")||t.hasOwnProperty("defaultValue")){var r=t.type;if(!(r!=="submit"&&r!=="reset"||t.value!==void 0&&t.value!==null))return;t=""+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}n=e.name,n!==""&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,n!==""&&(e.name=n)}function Jl(e,t,n){(t!=="number"||Tr(e.ownerDocument)!==e)&&(n==null?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+n&&(e.defaultValue=""+n))}var yn=Array.isArray;function Wt(e,t,n,r){if(e=e.options,t){t={};for(var l=0;l<n.length;l++)t["$"+n[l]]=!0;for(n=0;n<e.length;n++)l=t.hasOwnProperty("$"+e[n].value),e[n].selected!==l&&(e[n].selected=l),l&&r&&(e[n].defaultSelected=!0)}else{for(n=""+ct(n),t=null,l=0;l<e.length;l++){if(e[l].value===n){e[l].selected=!0,r&&(e[l].defaultSelected=!0);return}t!==null||e[l].disabled||(t=e[l])}t!==null&&(t.selected=!0)}}function ql(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(g(91));return B({},t,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function Ai(e,t){var n=t.value;if(n==null){if(n=t.children,t=t.defaultValue,n!=null){if(t!=null)throw Error(g(92));if(yn(n)){if(1<n.length)throw Error(g(93));n=n[0]}t=n}t==null&&(t=""),n=t}e._wrapperState={initialValue:ct(n)}}function sa(e,t){var n=ct(t.value),r=ct(t.defaultValue);n!=null&&(n=""+n,n!==e.value&&(e.value=n),t.defaultValue==null&&e.defaultValue!==n&&(e.defaultValue=n)),r!=null&&(e.defaultValue=""+r)}function Bi(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==""&&t!==null&&(e.value=t)}function ca(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function bl(e,t){return e==null||e==="http://www.w3.org/1999/xhtml"?ca(t):e==="http://www.w3.org/2000/svg"&&t==="foreignObject"?"http://www.w3.org/1999/xhtml":e}var rr,fa=function(e){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(t,n,r,l){MSApp.execUnsafeLocalFunction(function(){return e(t,n,r,l)})}:e}(function(e,t){if(e.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in e)e.innerHTML=t;else{for(rr=rr||document.createElement("div"),rr.innerHTML="<svg>"+t.valueOf().toString()+"</svg>",t=rr.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function Rn(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var xn={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Rc=["Webkit","ms","Moz","O"];Object.keys(xn).forEach(function(e){Rc.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),xn[t]=xn[e]})});function da(e,t,n){return t==null||typeof t=="boolean"||t===""?"":n||typeof t!="number"||t===0||xn.hasOwnProperty(e)&&xn[e]?(""+t).trim():t+"px"}function pa(e,t){e=e.style;for(var n in t)if(t.hasOwnProperty(n)){var r=n.indexOf("--")===0,l=da(n,t[n],r);n==="float"&&(n="cssFloat"),r?e.setProperty(n,l):e[n]=l}}var Oc=B({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function eo(e,t){if(t){if(Oc[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(g(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(g(60));if(typeof t.dangerouslySetInnerHTML!="object"||!("__html"in t.dangerouslySetInnerHTML))throw Error(g(61))}if(t.style!=null&&typeof t.style!="object")throw Error(g(62))}}function to(e,t){if(e.indexOf("-")===-1)return typeof t.is=="string";switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var no=null;function Yo(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var ro=null,Qt=null,Kt=null;function Vi(e){if(e=Zn(e)){if(typeof ro!="function")throw Error(g(280));var t=e.stateNode;t&&(t=ll(t),ro(e.stateNode,e.type,t))}}function ma(e){Qt?Kt?Kt.push(e):Kt=[e]:Qt=e}function va(){if(Qt){var e=Qt,t=Kt;if(Kt=Qt=null,Vi(e),t)for(e=0;e<t.length;e++)Vi(t[e])}}function ha(e,t){return e(t)}function ga(){}var Sl=!1;function ya(e,t,n){if(Sl)return e(t,n);Sl=!0;try{return ha(e,t,n)}finally{Sl=!1,(Qt!==null||Kt!==null)&&(ga(),va())}}function On(e,t){var n=e.stateNode;if(n===null)return null;var r=ll(n);if(r===null)return null;n=r[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(e=e.type,r=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!r;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(g(231,t,typeof n));return n}var lo=!1;if(We)try{var cn={};Object.defineProperty(cn,"passive",{get:function(){lo=!0}}),window.addEventListener("test",cn,cn),window.removeEventListener("test",cn,cn)}catch{lo=!1}function Dc(e,t,n,r,l,o,i,u,a){var c=Array.prototype.slice.call(arguments,3);try{t.apply(n,c)}catch(v){this.onError(v)}}var Sn=!1,Lr=null,Rr=!1,oo=null,Mc={onError:function(e){Sn=!0,Lr=e}};function Fc(e,t,n,r,l,o,i,u,a){Sn=!1,Lr=null,Dc.apply(Mc,arguments)}function Ic(e,t,n,r,l,o,i,u,a){if(Fc.apply(this,arguments),Sn){if(Sn){var c=Lr;Sn=!1,Lr=null}else throw Error(g(198));Rr||(Rr=!0,oo=c)}}function Lt(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function ka(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Hi(e){if(Lt(e)!==e)throw Error(g(188))}function jc(e){var t=e.alternate;if(!t){if(t=Lt(e),t===null)throw Error(g(188));return t!==e?null:e}for(var n=e,r=t;;){var l=n.return;if(l===null)break;var o=l.alternate;if(o===null){if(r=l.return,r!==null){n=r;continue}break}if(l.child===o.child){for(o=l.child;o;){if(o===n)return Hi(l),e;if(o===r)return Hi(l),t;o=o.sibling}throw Error(g(188))}if(n.return!==r.return)n=l,r=o;else{for(var i=!1,u=l.child;u;){if(u===n){i=!0,n=l,r=o;break}if(u===r){i=!0,r=l,n=o;break}u=u.sibling}if(!i){for(u=o.child;u;){if(u===n){i=!0,n=o,r=l;break}if(u===r){i=!0,r=o,n=l;break}u=u.sibling}if(!i)throw Error(g(189))}}if(n.alternate!==r)throw Error(g(190))}if(n.tag!==3)throw Error(g(188));return n.stateNode.current===n?e:t}function wa(e){return e=jc(e),e!==null?xa(e):null}function xa(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=xa(e);if(t!==null)return t;e=e.sibling}return null}var Sa=ge.unstable_scheduleCallback,Wi=ge.unstable_cancelCallback,$c=ge.unstable_shouldYield,Uc=ge.unstable_requestPaint,Q=ge.unstable_now,Ac=ge.unstable_getCurrentPriorityLevel,Xo=ge.unstable_ImmediatePriority,Ea=ge.unstable_UserBlockingPriority,Or=ge.unstable_NormalPriority,Bc=ge.unstable_LowPriority,Ca=ge.unstable_IdlePriority,el=null,je=null;function Vc(e){if(je&&typeof je.onCommitFiberRoot=="function")try{je.onCommitFiberRoot(el,e,void 0,(e.current.flags&128)===128)}catch{}}var Re=Math.clz32?Math.clz32:Qc,Hc=Math.log,Wc=Math.LN2;function Qc(e){return e>>>=0,e===0?32:31-(Hc(e)/Wc|0)|0}var lr=64,or=4194304;function kn(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function Dr(e,t){var n=e.pendingLanes;if(n===0)return 0;var r=0,l=e.suspendedLanes,o=e.pingedLanes,i=n&268435455;if(i!==0){var u=i&~l;u!==0?r=kn(u):(o&=i,o!==0&&(r=kn(o)))}else i=n&~l,i!==0?r=kn(i):o!==0&&(r=kn(o));if(r===0)return 0;if(t!==0&&t!==r&&!(t&l)&&(l=r&-r,o=t&-t,l>=o||l===16&&(o&4194240)!==0))return t;if(r&4&&(r|=n&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=r;0<t;)n=31-Re(t),l=1<<n,r|=e[n],t&=~l;return r}function Kc(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Yc(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,l=e.expirationTimes,o=e.pendingLanes;0<o;){var i=31-Re(o),u=1<<i,a=l[i];a===-1?(!(u&n)||u&r)&&(l[i]=Kc(u,t)):a<=t&&(e.expiredLanes|=u),o&=~u}}function io(e){return e=e.pendingLanes&-1073741825,e!==0?e:e&1073741824?1073741824:0}function _a(){var e=lr;return lr<<=1,!(lr&4194240)&&(lr=64),e}function El(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Xn(e,t,n){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-Re(t),e[t]=n}function Xc(e,t){var n=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var r=e.eventTimes;for(e=e.expirationTimes;0<n;){var l=31-Re(n),o=1<<l;t[l]=0,r[l]=-1,e[l]=-1,n&=~o}}function Go(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-Re(n),l=1<<r;l&t|e[r]&t&&(e[r]|=t),n&=~l}}var D=0;function za(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var Pa,Zo,Na,Ta,La,uo=!1,ir=[],nt=null,rt=null,lt=null,Dn=new Map,Mn=new Map,qe=[],Gc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Qi(e,t){switch(e){case"focusin":case"focusout":nt=null;break;case"dragenter":case"dragleave":rt=null;break;case"mouseover":case"mouseout":lt=null;break;case"pointerover":case"pointerout":Dn.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Mn.delete(t.pointerId)}}function fn(e,t,n,r,l,o){return e===null||e.nativeEvent!==o?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:o,targetContainers:[l]},t!==null&&(t=Zn(t),t!==null&&Zo(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,l!==null&&t.indexOf(l)===-1&&t.push(l),e)}function Zc(e,t,n,r,l){switch(t){case"focusin":return nt=fn(nt,e,t,n,r,l),!0;case"dragenter":return rt=fn(rt,e,t,n,r,l),!0;case"mouseover":return lt=fn(lt,e,t,n,r,l),!0;case"pointerover":var o=l.pointerId;return Dn.set(o,fn(Dn.get(o)||null,e,t,n,r,l)),!0;case"gotpointercapture":return o=l.pointerId,Mn.set(o,fn(Mn.get(o)||null,e,t,n,r,l)),!0}return!1}function Ra(e){var t=kt(e.target);if(t!==null){var n=Lt(t);if(n!==null){if(t=n.tag,t===13){if(t=ka(n),t!==null){e.blockedOn=t,La(e.priority,function(){Na(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function kr(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=ao(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);no=r,n.target.dispatchEvent(r),no=null}else return t=Zn(n),t!==null&&Zo(t),e.blockedOn=n,!1;t.shift()}return!0}function Ki(e,t,n){kr(e)&&n.delete(t)}function Jc(){uo=!1,nt!==null&&kr(nt)&&(nt=null),rt!==null&&kr(rt)&&(rt=null),lt!==null&&kr(lt)&&(lt=null),Dn.forEach(Ki),Mn.forEach(Ki)}function dn(e,t){e.blockedOn===t&&(e.blockedOn=null,uo||(uo=!0,ge.unstable_scheduleCallback(ge.unstable_NormalPriority,Jc)))}function Fn(e){function t(l){return dn(l,e)}if(0<ir.length){dn(ir[0],e);for(var n=1;n<ir.length;n++){var r=ir[n];r.blockedOn===e&&(r.blockedOn=null)}}for(nt!==null&&dn(nt,e),rt!==null&&dn(rt,e),lt!==null&&dn(lt,e),Dn.forEach(t),Mn.forEach(t),n=0;n<qe.length;n++)r=qe[n],r.blockedOn===e&&(r.blockedOn=null);for(;0<qe.length&&(n=qe[0],n.blockedOn===null);)Ra(n),n.blockedOn===null&&qe.shift()}var Yt=Xe.ReactCurrentBatchConfig,Mr=!0;function qc(e,t,n,r){var l=D,o=Yt.transition;Yt.transition=null;try{D=1,Jo(e,t,n,r)}finally{D=l,Yt.transition=o}}function bc(e,t,n,r){var l=D,o=Yt.transition;Yt.transition=null;try{D=4,Jo(e,t,n,r)}finally{D=l,Yt.transition=o}}function Jo(e,t,n,r){if(Mr){var l=ao(e,t,n,r);if(l===null)Dl(e,t,r,Fr,n),Qi(e,r);else if(Zc(l,e,t,n,r))r.stopPropagation();else if(Qi(e,r),t&4&&-1<Gc.indexOf(e)){for(;l!==null;){var o=Zn(l);if(o!==null&&Pa(o),o=ao(e,t,n,r),o===null&&Dl(e,t,r,Fr,n),o===l)break;l=o}l!==null&&r.stopPropagation()}else Dl(e,t,r,null,n)}}var Fr=null;function ao(e,t,n,r){if(Fr=null,e=Yo(r),e=kt(e),e!==null)if(t=Lt(e),t===null)e=null;else if(n=t.tag,n===13){if(e=ka(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null);return Fr=e,null}function Oa(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Ac()){case Xo:return 1;case Ea:return 4;case Or:case Bc:return 16;case Ca:return 536870912;default:return 16}default:return 16}}var et=null,qo=null,wr=null;function Da(){if(wr)return wr;var e,t=qo,n=t.length,r,l="value"in et?et.value:et.textContent,o=l.length;for(e=0;e<n&&t[e]===l[e];e++);var i=n-e;for(r=1;r<=i&&t[n-r]===l[o-r];r++);return wr=l.slice(e,1<r?1-r:void 0)}function xr(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function ur(){return!0}function Yi(){return!1}function ke(e){function t(n,r,l,o,i){this._reactName=n,this._targetInst=l,this.type=r,this.nativeEvent=o,this.target=i,this.currentTarget=null;for(var u in e)e.hasOwnProperty(u)&&(n=e[u],this[u]=n?n(o):o[u]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?ur:Yi,this.isPropagationStopped=Yi,this}return B(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=ur)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=ur)},persist:function(){},isPersistent:ur}),t}var ln={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},bo=ke(ln),Gn=B({},ln,{view:0,detail:0}),ef=ke(Gn),Cl,_l,pn,tl=B({},Gn,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ei,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==pn&&(pn&&e.type==="mousemove"?(Cl=e.screenX-pn.screenX,_l=e.screenY-pn.screenY):_l=Cl=0,pn=e),Cl)},movementY:function(e){return"movementY"in e?e.movementY:_l}}),Xi=ke(tl),tf=B({},tl,{dataTransfer:0}),nf=ke(tf),rf=B({},Gn,{relatedTarget:0}),zl=ke(rf),lf=B({},ln,{animationName:0,elapsedTime:0,pseudoElement:0}),of=ke(lf),uf=B({},ln,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),af=ke(uf),sf=B({},ln,{data:0}),Gi=ke(sf),cf={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},ff={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},df={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function pf(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=df[e])?!!t[e]:!1}function ei(){return pf}var mf=B({},Gn,{key:function(e){if(e.key){var t=cf[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=xr(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?ff[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ei,charCode:function(e){return e.type==="keypress"?xr(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?xr(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),vf=ke(mf),hf=B({},tl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Zi=ke(hf),gf=B({},Gn,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ei}),yf=ke(gf),kf=B({},ln,{propertyName:0,elapsedTime:0,pseudoElement:0}),wf=ke(kf),xf=B({},tl,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Sf=ke(xf),Ef=[9,13,27,32],ti=We&&"CompositionEvent"in window,En=null;We&&"documentMode"in document&&(En=document.documentMode);var Cf=We&&"TextEvent"in window&&!En,Ma=We&&(!ti||En&&8<En&&11>=En),Ji=" ",qi=!1;function Fa(e,t){switch(e){case"keyup":return Ef.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Ia(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Mt=!1;function _f(e,t){switch(e){case"compositionend":return Ia(t);case"keypress":return t.which!==32?null:(qi=!0,Ji);case"textInput":return e=t.data,e===Ji&&qi?null:e;default:return null}}function zf(e,t){if(Mt)return e==="compositionend"||!ti&&Fa(e,t)?(e=Da(),wr=qo=et=null,Mt=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Ma&&t.locale!=="ko"?null:t.data;default:return null}}var Pf={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function bi(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Pf[e.type]:t==="textarea"}function ja(e,t,n,r){ma(r),t=Ir(t,"onChange"),0<t.length&&(n=new bo("onChange","change",null,n,r),e.push({event:n,listeners:t}))}var Cn=null,In=null;function Nf(e){Xa(e,0)}function nl(e){var t=jt(e);if(ua(t))return e}function Tf(e,t){if(e==="change")return t}var $a=!1;if(We){var Pl;if(We){var Nl="oninput"in document;if(!Nl){var eu=document.createElement("div");eu.setAttribute("oninput","return;"),Nl=typeof eu.oninput=="function"}Pl=Nl}else Pl=!1;$a=Pl&&(!document.documentMode||9<document.documentMode)}function tu(){Cn&&(Cn.detachEvent("onpropertychange",Ua),In=Cn=null)}function Ua(e){if(e.propertyName==="value"&&nl(In)){var t=[];ja(t,In,e,Yo(e)),ya(Nf,t)}}function Lf(e,t,n){e==="focusin"?(tu(),Cn=t,In=n,Cn.attachEvent("onpropertychange",Ua)):e==="focusout"&&tu()}function Rf(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return nl(In)}function Of(e,t){if(e==="click")return nl(t)}function Df(e,t){if(e==="input"||e==="change")return nl(t)}function Mf(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var De=typeof Object.is=="function"?Object.is:Mf;function jn(e,t){if(De(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var l=n[r];if(!Wl.call(t,l)||!De(e[l],t[l]))return!1}return!0}function nu(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function ru(e,t){var n=nu(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=nu(n)}}function Aa(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Aa(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Ba(){for(var e=window,t=Tr();t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=Tr(e.document)}return t}function ni(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}function Ff(e){var t=Ba(),n=e.focusedElem,r=e.selectionRange;if(t!==n&&n&&n.ownerDocument&&Aa(n.ownerDocument.documentElement,n)){if(r!==null&&ni(n)){if(t=r.start,e=r.end,e===void 0&&(e=t),"selectionStart"in n)n.selectionStart=t,n.selectionEnd=Math.min(e,n.value.length);else if(e=(t=n.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var l=n.textContent.length,o=Math.min(r.start,l);r=r.end===void 0?o:Math.min(r.end,l),!e.extend&&o>r&&(l=r,r=o,o=l),l=ru(n,o);var i=ru(n,r);l&&i&&(e.rangeCount!==1||e.anchorNode!==l.node||e.anchorOffset!==l.offset||e.focusNode!==i.node||e.focusOffset!==i.offset)&&(t=t.createRange(),t.setStart(l.node,l.offset),e.removeAllRanges(),o>r?(e.addRange(t),e.extend(i.node,i.offset)):(t.setEnd(i.node,i.offset),e.addRange(t)))}}for(t=[],e=n;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof n.focus=="function"&&n.focus(),n=0;n<t.length;n++)e=t[n],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var If=We&&"documentMode"in document&&11>=document.documentMode,Ft=null,so=null,_n=null,co=!1;function lu(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;co||Ft==null||Ft!==Tr(r)||(r=Ft,"selectionStart"in r&&ni(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),_n&&jn(_n,r)||(_n=r,r=Ir(so,"onSelect"),0<r.length&&(t=new bo("onSelect","select",null,t,n),e.push({event:t,listeners:r}),t.target=Ft)))}function ar(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var It={animationend:ar("Animation","AnimationEnd"),animationiteration:ar("Animation","AnimationIteration"),animationstart:ar("Animation","AnimationStart"),transitionend:ar("Transition","TransitionEnd")},Tl={},Va={};We&&(Va=document.createElement("div").style,"AnimationEvent"in window||(delete It.animationend.animation,delete It.animationiteration.animation,delete It.animationstart.animation),"TransitionEvent"in window||delete It.transitionend.transition);function rl(e){if(Tl[e])return Tl[e];if(!It[e])return e;var t=It[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in Va)return Tl[e]=t[n];return e}var Ha=rl("animationend"),Wa=rl("animationiteration"),Qa=rl("animationstart"),Ka=rl("transitionend"),Ya=new Map,ou="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function dt(e,t){Ya.set(e,t),Tt(t,[e])}for(var Ll=0;Ll<ou.length;Ll++){var Rl=ou[Ll],jf=Rl.toLowerCase(),$f=Rl[0].toUpperCase()+Rl.slice(1);dt(jf,"on"+$f)}dt(Ha,"onAnimationEnd");dt(Wa,"onAnimationIteration");dt(Qa,"onAnimationStart");dt("dblclick","onDoubleClick");dt("focusin","onFocus");dt("focusout","onBlur");dt(Ka,"onTransitionEnd");Zt("onMouseEnter",["mouseout","mouseover"]);Zt("onMouseLeave",["mouseout","mouseover"]);Zt("onPointerEnter",["pointerout","pointerover"]);Zt("onPointerLeave",["pointerout","pointerover"]);Tt("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));Tt("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));Tt("onBeforeInput",["compositionend","keypress","textInput","paste"]);Tt("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));Tt("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));Tt("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var wn="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Uf=new Set("cancel close invalid load scroll toggle".split(" ").concat(wn));function iu(e,t,n){var r=e.type||"unknown-event";e.currentTarget=n,Ic(r,t,void 0,e),e.currentTarget=null}function Xa(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var r=e[n],l=r.event;r=r.listeners;e:{var o=void 0;if(t)for(var i=r.length-1;0<=i;i--){var u=r[i],a=u.instance,c=u.currentTarget;if(u=u.listener,a!==o&&l.isPropagationStopped())break e;iu(l,u,c),o=a}else for(i=0;i<r.length;i++){if(u=r[i],a=u.instance,c=u.currentTarget,u=u.listener,a!==o&&l.isPropagationStopped())break e;iu(l,u,c),o=a}}}if(Rr)throw e=oo,Rr=!1,oo=null,e}function F(e,t){var n=t[ho];n===void 0&&(n=t[ho]=new Set);var r=e+"__bubble";n.has(r)||(Ga(t,e,2,!1),n.add(r))}function Ol(e,t,n){var r=0;t&&(r|=4),Ga(n,e,r,t)}var sr="_reactListening"+Math.random().toString(36).slice(2);function $n(e){if(!e[sr]){e[sr]=!0,na.forEach(function(n){n!=="selectionchange"&&(Uf.has(n)||Ol(n,!1,e),Ol(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[sr]||(t[sr]=!0,Ol("selectionchange",!1,t))}}function Ga(e,t,n,r){switch(Oa(t)){case 1:var l=qc;break;case 4:l=bc;break;default:l=Jo}n=l.bind(null,t,n,e),l=void 0,!lo||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(l=!0),r?l!==void 0?e.addEventListener(t,n,{capture:!0,passive:l}):e.addEventListener(t,n,!0):l!==void 0?e.addEventListener(t,n,{passive:l}):e.addEventListener(t,n,!1)}function Dl(e,t,n,r,l){var o=r;if(!(t&1)&&!(t&2)&&r!==null)e:for(;;){if(r===null)return;var i=r.tag;if(i===3||i===4){var u=r.stateNode.containerInfo;if(u===l||u.nodeType===8&&u.parentNode===l)break;if(i===4)for(i=r.return;i!==null;){var a=i.tag;if((a===3||a===4)&&(a=i.stateNode.containerInfo,a===l||a.nodeType===8&&a.parentNode===l))return;i=i.return}for(;u!==null;){if(i=kt(u),i===null)return;if(a=i.tag,a===5||a===6){r=o=i;continue e}u=u.parentNode}}r=r.return}ya(function(){var c=o,v=Yo(n),m=[];e:{var p=Ya.get(e);if(p!==void 0){var y=bo,k=e;switch(e){case"keypress":if(xr(n)===0)break e;case"keydown":case"keyup":y=vf;break;case"focusin":k="focus",y=zl;break;case"focusout":k="blur",y=zl;break;case"beforeblur":case"afterblur":y=zl;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":y=Xi;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":y=nf;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":y=yf;break;case Ha:case Wa:case Qa:y=of;break;case Ka:y=wf;break;case"scroll":y=ef;break;case"wheel":y=Sf;break;case"copy":case"cut":case"paste":y=af;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":y=Zi}var w=(t&4)!==0,j=!w&&e==="scroll",f=w?p!==null?p+"Capture":null:p;w=[];for(var s=c,d;s!==null;){d=s;var h=d.stateNode;if(d.tag===5&&h!==null&&(d=h,f!==null&&(h=On(s,f),h!=null&&w.push(Un(s,h,d)))),j)break;s=s.return}0<w.length&&(p=new y(p,k,null,n,v),m.push({event:p,listeners:w}))}}if(!(t&7)){e:{if(p=e==="mouseover"||e==="pointerover",y=e==="mouseout"||e==="pointerout",p&&n!==no&&(k=n.relatedTarget||n.fromElement)&&(kt(k)||k[Qe]))break e;if((y||p)&&(p=v.window===v?v:(p=v.ownerDocument)?p.defaultView||p.parentWindow:window,y?(k=n.relatedTarget||n.toElement,y=c,k=k?kt(k):null,k!==null&&(j=Lt(k),k!==j||k.tag!==5&&k.tag!==6)&&(k=null)):(y=null,k=c),y!==k)){if(w=Xi,h="onMouseLeave",f="onMouseEnter",s="mouse",(e==="pointerout"||e==="pointerover")&&(w=Zi,h="onPointerLeave",f="onPointerEnter",s="pointer"),j=y==null?p:jt(y),d=k==null?p:jt(k),p=new w(h,s+"leave",y,n,v),p.target=j,p.relatedTarget=d,h=null,kt(v)===c&&(w=new w(f,s+"enter",k,n,v),w.target=d,w.relatedTarget=j,h=w),j=h,y&&k)t:{for(w=y,f=k,s=0,d=w;d;d=Rt(d))s++;for(d=0,h=f;h;h=Rt(h))d++;for(;0<s-d;)w=Rt(w),s--;for(;0<d-s;)f=Rt(f),d--;for(;s--;){if(w===f||f!==null&&w===f.alternate)break t;w=Rt(w),f=Rt(f)}w=null}else w=null;y!==null&&uu(m,p,y,w,!1),k!==null&&j!==null&&uu(m,j,k,w,!0)}}e:{if(p=c?jt(c):window,y=p.nodeName&&p.nodeName.toLowerCase(),y==="select"||y==="input"&&p.type==="file")var S=Tf;else if(bi(p))if($a)S=Df;else{S=Rf;var C=Lf}else(y=p.nodeName)&&y.toLowerCase()==="input"&&(p.type==="checkbox"||p.type==="radio")&&(S=Of);if(S&&(S=S(e,c))){ja(m,S,n,v);break e}C&&C(e,p,c),e==="focusout"&&(C=p._wrapperState)&&C.controlled&&p.type==="number"&&Jl(p,"number",p.value)}switch(C=c?jt(c):window,e){case"focusin":(bi(C)||C.contentEditable==="true")&&(Ft=C,so=c,_n=null);break;case"focusout":_n=so=Ft=null;break;case"mousedown":co=!0;break;case"contextmenu":case"mouseup":case"dragend":co=!1,lu(m,n,v);break;case"selectionchange":if(If)break;case"keydown":case"keyup":lu(m,n,v)}var _;if(ti)e:{switch(e){case"compositionstart":var z="onCompositionStart";break e;case"compositionend":z="onCompositionEnd";break e;case"compositionupdate":z="onCompositionUpdate";break e}z=void 0}else Mt?Fa(e,n)&&(z="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(z="onCompositionStart");z&&(Ma&&n.locale!=="ko"&&(Mt||z!=="onCompositionStart"?z==="onCompositionEnd"&&Mt&&(_=Da()):(et=v,qo="value"in et?et.value:et.textContent,Mt=!0)),C=Ir(c,z),0<C.length&&(z=new Gi(z,e,null,n,v),m.push({event:z,listeners:C}),_?z.data=_:(_=Ia(n),_!==null&&(z.data=_)))),(_=Cf?_f(e,n):zf(e,n))&&(c=Ir(c,"onBeforeInput"),0<c.length&&(v=new Gi("onBeforeInput","beforeinput",null,n,v),m.push({event:v,listeners:c}),v.data=_))}Xa(m,t)})}function Un(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Ir(e,t){for(var n=t+"Capture",r=[];e!==null;){var l=e,o=l.stateNode;l.tag===5&&o!==null&&(l=o,o=On(e,n),o!=null&&r.unshift(Un(e,o,l)),o=On(e,t),o!=null&&r.push(Un(e,o,l))),e=e.return}return r}function Rt(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function uu(e,t,n,r,l){for(var o=t._reactName,i=[];n!==null&&n!==r;){var u=n,a=u.alternate,c=u.stateNode;if(a!==null&&a===r)break;u.tag===5&&c!==null&&(u=c,l?(a=On(n,o),a!=null&&i.unshift(Un(n,a,u))):l||(a=On(n,o),a!=null&&i.push(Un(n,a,u)))),n=n.return}i.length!==0&&e.push({event:t,listeners:i})}var Af=/\r\n?/g,Bf=/\u0000|\uFFFD/g;function au(e){return(typeof e=="string"?e:""+e).replace(Af,`
`).replace(Bf,"")}function cr(e,t,n){if(t=au(t),au(e)!==t&&n)throw Error(g(425))}function jr(){}var fo=null,po=null;function mo(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var vo=typeof setTimeout=="function"?setTimeout:void 0,Vf=typeof clearTimeout=="function"?clearTimeout:void 0,su=typeof Promise=="function"?Promise:void 0,Hf=typeof queueMicrotask=="function"?queueMicrotask:typeof su<"u"?function(e){return su.resolve(null).then(e).catch(Wf)}:vo;function Wf(e){setTimeout(function(){throw e})}function Ml(e,t){var n=t,r=0;do{var l=n.nextSibling;if(e.removeChild(n),l&&l.nodeType===8)if(n=l.data,n==="/$"){if(r===0){e.removeChild(l),Fn(t);return}r--}else n!=="$"&&n!=="$?"&&n!=="$!"||r++;n=l}while(n);Fn(t)}function ot(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?")break;if(t==="/$")return null}}return e}function cu(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"){if(t===0)return e;t--}else n==="/$"&&t++}e=e.previousSibling}return null}var on=Math.random().toString(36).slice(2),Ie="__reactFiber$"+on,An="__reactProps$"+on,Qe="__reactContainer$"+on,ho="__reactEvents$"+on,Qf="__reactListeners$"+on,Kf="__reactHandles$"+on;function kt(e){var t=e[Ie];if(t)return t;for(var n=e.parentNode;n;){if(t=n[Qe]||n[Ie]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=cu(e);e!==null;){if(n=e[Ie])return n;e=cu(e)}return t}e=n,n=e.parentNode}return null}function Zn(e){return e=e[Ie]||e[Qe],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function jt(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(g(33))}function ll(e){return e[An]||null}var go=[],$t=-1;function pt(e){return{current:e}}function I(e){0>$t||(e.current=go[$t],go[$t]=null,$t--)}function M(e,t){$t++,go[$t]=e.current,e.current=t}var ft={},le=pt(ft),fe=pt(!1),Ct=ft;function Jt(e,t){var n=e.type.contextTypes;if(!n)return ft;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var l={},o;for(o in n)l[o]=t[o];return r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=l),l}function de(e){return e=e.childContextTypes,e!=null}function $r(){I(fe),I(le)}function fu(e,t,n){if(le.current!==ft)throw Error(g(168));M(le,t),M(fe,n)}function Za(e,t,n){var r=e.stateNode;if(t=t.childContextTypes,typeof r.getChildContext!="function")return n;r=r.getChildContext();for(var l in r)if(!(l in t))throw Error(g(108,Tc(e)||"Unknown",l));return B({},n,r)}function Ur(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||ft,Ct=le.current,M(le,e),M(fe,fe.current),!0}function du(e,t,n){var r=e.stateNode;if(!r)throw Error(g(169));n?(e=Za(e,t,Ct),r.__reactInternalMemoizedMergedChildContext=e,I(fe),I(le),M(le,e)):I(fe),M(fe,n)}var Ae=null,ol=!1,Fl=!1;function Ja(e){Ae===null?Ae=[e]:Ae.push(e)}function Yf(e){ol=!0,Ja(e)}function mt(){if(!Fl&&Ae!==null){Fl=!0;var e=0,t=D;try{var n=Ae;for(D=1;e<n.length;e++){var r=n[e];do r=r(!0);while(r!==null)}Ae=null,ol=!1}catch(l){throw Ae!==null&&(Ae=Ae.slice(e+1)),Sa(Xo,mt),l}finally{D=t,Fl=!1}}return null}var Ut=[],At=0,Ar=null,Br=0,we=[],xe=0,_t=null,Be=1,Ve="";function gt(e,t){Ut[At++]=Br,Ut[At++]=Ar,Ar=e,Br=t}function qa(e,t,n){we[xe++]=Be,we[xe++]=Ve,we[xe++]=_t,_t=e;var r=Be;e=Ve;var l=32-Re(r)-1;r&=~(1<<l),n+=1;var o=32-Re(t)+l;if(30<o){var i=l-l%5;o=(r&(1<<i)-1).toString(32),r>>=i,l-=i,Be=1<<32-Re(t)+l|n<<l|r,Ve=o+e}else Be=1<<o|n<<l|r,Ve=e}function ri(e){e.return!==null&&(gt(e,1),qa(e,1,0))}function li(e){for(;e===Ar;)Ar=Ut[--At],Ut[At]=null,Br=Ut[--At],Ut[At]=null;for(;e===_t;)_t=we[--xe],we[xe]=null,Ve=we[--xe],we[xe]=null,Be=we[--xe],we[xe]=null}var he=null,ve=null,$=!1,Le=null;function ba(e,t){var n=Se(5,null,null,0);n.elementType="DELETED",n.stateNode=t,n.return=e,t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)}function pu(e,t){switch(e.tag){case 5:var n=e.type;return t=t.nodeType!==1||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null?(e.stateNode=t,he=e,ve=ot(t.firstChild),!0):!1;case 6:return t=e.pendingProps===""||t.nodeType!==3?null:t,t!==null?(e.stateNode=t,he=e,ve=null,!0):!1;case 13:return t=t.nodeType!==8?null:t,t!==null?(n=_t!==null?{id:Be,overflow:Ve}:null,e.memoizedState={dehydrated:t,treeContext:n,retryLane:1073741824},n=Se(18,null,null,0),n.stateNode=t,n.return=e,e.child=n,he=e,ve=null,!0):!1;default:return!1}}function yo(e){return(e.mode&1)!==0&&(e.flags&128)===0}function ko(e){if($){var t=ve;if(t){var n=t;if(!pu(e,t)){if(yo(e))throw Error(g(418));t=ot(n.nextSibling);var r=he;t&&pu(e,t)?ba(r,n):(e.flags=e.flags&-4097|2,$=!1,he=e)}}else{if(yo(e))throw Error(g(418));e.flags=e.flags&-4097|2,$=!1,he=e}}}function mu(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;he=e}function fr(e){if(e!==he)return!1;if(!$)return mu(e),$=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!=="head"&&t!=="body"&&!mo(e.type,e.memoizedProps)),t&&(t=ve)){if(yo(e))throw es(),Error(g(418));for(;t;)ba(e,t),t=ot(t.nextSibling)}if(mu(e),e.tag===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(g(317));e:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"){if(t===0){ve=ot(e.nextSibling);break e}t--}else n!=="$"&&n!=="$!"&&n!=="$?"||t++}e=e.nextSibling}ve=null}}else ve=he?ot(e.stateNode.nextSibling):null;return!0}function es(){for(var e=ve;e;)e=ot(e.nextSibling)}function qt(){ve=he=null,$=!1}function oi(e){Le===null?Le=[e]:Le.push(e)}var Xf=Xe.ReactCurrentBatchConfig;function mn(e,t,n){if(e=n.ref,e!==null&&typeof e!="function"&&typeof e!="object"){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(g(309));var r=n.stateNode}if(!r)throw Error(g(147,e));var l=r,o=""+e;return t!==null&&t.ref!==null&&typeof t.ref=="function"&&t.ref._stringRef===o?t.ref:(t=function(i){var u=l.refs;i===null?delete u[o]:u[o]=i},t._stringRef=o,t)}if(typeof e!="string")throw Error(g(284));if(!n._owner)throw Error(g(290,e))}return e}function dr(e,t){throw e=Object.prototype.toString.call(t),Error(g(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function vu(e){var t=e._init;return t(e._payload)}function ts(e){function t(f,s){if(e){var d=f.deletions;d===null?(f.deletions=[s],f.flags|=16):d.push(s)}}function n(f,s){if(!e)return null;for(;s!==null;)t(f,s),s=s.sibling;return null}function r(f,s){for(f=new Map;s!==null;)s.key!==null?f.set(s.key,s):f.set(s.index,s),s=s.sibling;return f}function l(f,s){return f=st(f,s),f.index=0,f.sibling=null,f}function o(f,s,d){return f.index=d,e?(d=f.alternate,d!==null?(d=d.index,d<s?(f.flags|=2,s):d):(f.flags|=2,s)):(f.flags|=1048576,s)}function i(f){return e&&f.alternate===null&&(f.flags|=2),f}function u(f,s,d,h){return s===null||s.tag!==6?(s=Vl(d,f.mode,h),s.return=f,s):(s=l(s,d),s.return=f,s)}function a(f,s,d,h){var S=d.type;return S===Dt?v(f,s,d.props.children,h,d.key):s!==null&&(s.elementType===S||typeof S=="object"&&S!==null&&S.$$typeof===Ze&&vu(S)===s.type)?(h=l(s,d.props),h.ref=mn(f,s,d),h.return=f,h):(h=Nr(d.type,d.key,d.props,null,f.mode,h),h.ref=mn(f,s,d),h.return=f,h)}function c(f,s,d,h){return s===null||s.tag!==4||s.stateNode.containerInfo!==d.containerInfo||s.stateNode.implementation!==d.implementation?(s=Hl(d,f.mode,h),s.return=f,s):(s=l(s,d.children||[]),s.return=f,s)}function v(f,s,d,h,S){return s===null||s.tag!==7?(s=Et(d,f.mode,h,S),s.return=f,s):(s=l(s,d),s.return=f,s)}function m(f,s,d){if(typeof s=="string"&&s!==""||typeof s=="number")return s=Vl(""+s,f.mode,d),s.return=f,s;if(typeof s=="object"&&s!==null){switch(s.$$typeof){case tr:return d=Nr(s.type,s.key,s.props,null,f.mode,d),d.ref=mn(f,null,s),d.return=f,d;case Ot:return s=Hl(s,f.mode,d),s.return=f,s;case Ze:var h=s._init;return m(f,h(s._payload),d)}if(yn(s)||sn(s))return s=Et(s,f.mode,d,null),s.return=f,s;dr(f,s)}return null}function p(f,s,d,h){var S=s!==null?s.key:null;if(typeof d=="string"&&d!==""||typeof d=="number")return S!==null?null:u(f,s,""+d,h);if(typeof d=="object"&&d!==null){switch(d.$$typeof){case tr:return d.key===S?a(f,s,d,h):null;case Ot:return d.key===S?c(f,s,d,h):null;case Ze:return S=d._init,p(f,s,S(d._payload),h)}if(yn(d)||sn(d))return S!==null?null:v(f,s,d,h,null);dr(f,d)}return null}function y(f,s,d,h,S){if(typeof h=="string"&&h!==""||typeof h=="number")return f=f.get(d)||null,u(s,f,""+h,S);if(typeof h=="object"&&h!==null){switch(h.$$typeof){case tr:return f=f.get(h.key===null?d:h.key)||null,a(s,f,h,S);case Ot:return f=f.get(h.key===null?d:h.key)||null,c(s,f,h,S);case Ze:var C=h._init;return y(f,s,d,C(h._payload),S)}if(yn(h)||sn(h))return f=f.get(d)||null,v(s,f,h,S,null);dr(s,h)}return null}function k(f,s,d,h){for(var S=null,C=null,_=s,z=s=0,H=null;_!==null&&z<d.length;z++){_.index>z?(H=_,_=null):H=_.sibling;var R=p(f,_,d[z],h);if(R===null){_===null&&(_=H);break}e&&_&&R.alternate===null&&t(f,_),s=o(R,s,z),C===null?S=R:C.sibling=R,C=R,_=H}if(z===d.length)return n(f,_),$&&gt(f,z),S;if(_===null){for(;z<d.length;z++)_=m(f,d[z],h),_!==null&&(s=o(_,s,z),C===null?S=_:C.sibling=_,C=_);return $&&gt(f,z),S}for(_=r(f,_);z<d.length;z++)H=y(_,f,z,d[z],h),H!==null&&(e&&H.alternate!==null&&_.delete(H.key===null?z:H.key),s=o(H,s,z),C===null?S=H:C.sibling=H,C=H);return e&&_.forEach(function(ze){return t(f,ze)}),$&&gt(f,z),S}function w(f,s,d,h){var S=sn(d);if(typeof S!="function")throw Error(g(150));if(d=S.call(d),d==null)throw Error(g(151));for(var C=S=null,_=s,z=s=0,H=null,R=d.next();_!==null&&!R.done;z++,R=d.next()){_.index>z?(H=_,_=null):H=_.sibling;var ze=p(f,_,R.value,h);if(ze===null){_===null&&(_=H);break}e&&_&&ze.alternate===null&&t(f,_),s=o(ze,s,z),C===null?S=ze:C.sibling=ze,C=ze,_=H}if(R.done)return n(f,_),$&&gt(f,z),S;if(_===null){for(;!R.done;z++,R=d.next())R=m(f,R.value,h),R!==null&&(s=o(R,s,z),C===null?S=R:C.sibling=R,C=R);return $&&gt(f,z),S}for(_=r(f,_);!R.done;z++,R=d.next())R=y(_,f,z,R.value,h),R!==null&&(e&&R.alternate!==null&&_.delete(R.key===null?z:R.key),s=o(R,s,z),C===null?S=R:C.sibling=R,C=R);return e&&_.forEach(function(un){return t(f,un)}),$&&gt(f,z),S}function j(f,s,d,h){if(typeof d=="object"&&d!==null&&d.type===Dt&&d.key===null&&(d=d.props.children),typeof d=="object"&&d!==null){switch(d.$$typeof){case tr:e:{for(var S=d.key,C=s;C!==null;){if(C.key===S){if(S=d.type,S===Dt){if(C.tag===7){n(f,C.sibling),s=l(C,d.props.children),s.return=f,f=s;break e}}else if(C.elementType===S||typeof S=="object"&&S!==null&&S.$$typeof===Ze&&vu(S)===C.type){n(f,C.sibling),s=l(C,d.props),s.ref=mn(f,C,d),s.return=f,f=s;break e}n(f,C);break}else t(f,C);C=C.sibling}d.type===Dt?(s=Et(d.props.children,f.mode,h,d.key),s.return=f,f=s):(h=Nr(d.type,d.key,d.props,null,f.mode,h),h.ref=mn(f,s,d),h.return=f,f=h)}return i(f);case Ot:e:{for(C=d.key;s!==null;){if(s.key===C)if(s.tag===4&&s.stateNode.containerInfo===d.containerInfo&&s.stateNode.implementation===d.implementation){n(f,s.sibling),s=l(s,d.children||[]),s.return=f,f=s;break e}else{n(f,s);break}else t(f,s);s=s.sibling}s=Hl(d,f.mode,h),s.return=f,f=s}return i(f);case Ze:return C=d._init,j(f,s,C(d._payload),h)}if(yn(d))return k(f,s,d,h);if(sn(d))return w(f,s,d,h);dr(f,d)}return typeof d=="string"&&d!==""||typeof d=="number"?(d=""+d,s!==null&&s.tag===6?(n(f,s.sibling),s=l(s,d),s.return=f,f=s):(n(f,s),s=Vl(d,f.mode,h),s.return=f,f=s),i(f)):n(f,s)}return j}var bt=ts(!0),ns=ts(!1),Vr=pt(null),Hr=null,Bt=null,ii=null;function ui(){ii=Bt=Hr=null}function ai(e){var t=Vr.current;I(Vr),e._currentValue=t}function wo(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,r!==null&&(r.childLanes|=t)):r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t),e===n)break;e=e.return}}function Xt(e,t){Hr=e,ii=Bt=null,e=e.dependencies,e!==null&&e.firstContext!==null&&(e.lanes&t&&(ce=!0),e.firstContext=null)}function Ce(e){var t=e._currentValue;if(ii!==e)if(e={context:e,memoizedValue:t,next:null},Bt===null){if(Hr===null)throw Error(g(308));Bt=e,Hr.dependencies={lanes:0,firstContext:e}}else Bt=Bt.next=e;return t}var wt=null;function si(e){wt===null?wt=[e]:wt.push(e)}function rs(e,t,n,r){var l=t.interleaved;return l===null?(n.next=n,si(t)):(n.next=l.next,l.next=n),t.interleaved=n,Ke(e,r)}function Ke(e,t){e.lanes|=t;var n=e.alternate;for(n!==null&&(n.lanes|=t),n=e,e=e.return;e!==null;)e.childLanes|=t,n=e.alternate,n!==null&&(n.childLanes|=t),n=e,e=e.return;return n.tag===3?n.stateNode:null}var Je=!1;function ci(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function ls(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function He(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function it(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,O&2){var l=r.pending;return l===null?t.next=t:(t.next=l.next,l.next=t),r.pending=t,Ke(e,n)}return l=r.interleaved,l===null?(t.next=t,si(r)):(t.next=l.next,l.next=t),r.interleaved=t,Ke(e,n)}function Sr(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194240)!==0)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Go(e,n)}}function hu(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var l=null,o=null;if(n=n.firstBaseUpdate,n!==null){do{var i={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};o===null?l=o=i:o=o.next=i,n=n.next}while(n!==null);o===null?l=o=t:o=o.next=t}else l=o=t;n={baseState:r.baseState,firstBaseUpdate:l,lastBaseUpdate:o,shared:r.shared,effects:r.effects},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function Wr(e,t,n,r){var l=e.updateQueue;Je=!1;var o=l.firstBaseUpdate,i=l.lastBaseUpdate,u=l.shared.pending;if(u!==null){l.shared.pending=null;var a=u,c=a.next;a.next=null,i===null?o=c:i.next=c,i=a;var v=e.alternate;v!==null&&(v=v.updateQueue,u=v.lastBaseUpdate,u!==i&&(u===null?v.firstBaseUpdate=c:u.next=c,v.lastBaseUpdate=a))}if(o!==null){var m=l.baseState;i=0,v=c=a=null,u=o;do{var p=u.lane,y=u.eventTime;if((r&p)===p){v!==null&&(v=v.next={eventTime:y,lane:0,tag:u.tag,payload:u.payload,callback:u.callback,next:null});e:{var k=e,w=u;switch(p=t,y=n,w.tag){case 1:if(k=w.payload,typeof k=="function"){m=k.call(y,m,p);break e}m=k;break e;case 3:k.flags=k.flags&-65537|128;case 0:if(k=w.payload,p=typeof k=="function"?k.call(y,m,p):k,p==null)break e;m=B({},m,p);break e;case 2:Je=!0}}u.callback!==null&&u.lane!==0&&(e.flags|=64,p=l.effects,p===null?l.effects=[u]:p.push(u))}else y={eventTime:y,lane:p,tag:u.tag,payload:u.payload,callback:u.callback,next:null},v===null?(c=v=y,a=m):v=v.next=y,i|=p;if(u=u.next,u===null){if(u=l.shared.pending,u===null)break;p=u,u=p.next,p.next=null,l.lastBaseUpdate=p,l.shared.pending=null}}while(!0);if(v===null&&(a=m),l.baseState=a,l.firstBaseUpdate=c,l.lastBaseUpdate=v,t=l.shared.interleaved,t!==null){l=t;do i|=l.lane,l=l.next;while(l!==t)}else o===null&&(l.shared.lanes=0);Pt|=i,e.lanes=i,e.memoizedState=m}}function gu(e,t,n){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var r=e[t],l=r.callback;if(l!==null){if(r.callback=null,r=n,typeof l!="function")throw Error(g(191,l));l.call(r)}}}var Jn={},$e=pt(Jn),Bn=pt(Jn),Vn=pt(Jn);function xt(e){if(e===Jn)throw Error(g(174));return e}function fi(e,t){switch(M(Vn,t),M(Bn,e),M($e,Jn),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:bl(null,"");break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=bl(t,e)}I($e),M($e,t)}function en(){I($e),I(Bn),I(Vn)}function os(e){xt(Vn.current);var t=xt($e.current),n=bl(t,e.type);t!==n&&(M(Bn,e),M($e,n))}function di(e){Bn.current===e&&(I($e),I(Bn))}var U=pt(0);function Qr(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data==="$?"||n.data==="$!"))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Il=[];function pi(){for(var e=0;e<Il.length;e++)Il[e]._workInProgressVersionPrimary=null;Il.length=0}var Er=Xe.ReactCurrentDispatcher,jl=Xe.ReactCurrentBatchConfig,zt=0,A=null,Y=null,Z=null,Kr=!1,zn=!1,Hn=0,Gf=0;function te(){throw Error(g(321))}function mi(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!De(e[n],t[n]))return!1;return!0}function vi(e,t,n,r,l,o){if(zt=o,A=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,Er.current=e===null||e.memoizedState===null?bf:ed,e=n(r,l),zn){o=0;do{if(zn=!1,Hn=0,25<=o)throw Error(g(301));o+=1,Z=Y=null,t.updateQueue=null,Er.current=td,e=n(r,l)}while(zn)}if(Er.current=Yr,t=Y!==null&&Y.next!==null,zt=0,Z=Y=A=null,Kr=!1,t)throw Error(g(300));return e}function hi(){var e=Hn!==0;return Hn=0,e}function Fe(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Z===null?A.memoizedState=Z=e:Z=Z.next=e,Z}function _e(){if(Y===null){var e=A.alternate;e=e!==null?e.memoizedState:null}else e=Y.next;var t=Z===null?A.memoizedState:Z.next;if(t!==null)Z=t,Y=e;else{if(e===null)throw Error(g(310));Y=e,e={memoizedState:Y.memoizedState,baseState:Y.baseState,baseQueue:Y.baseQueue,queue:Y.queue,next:null},Z===null?A.memoizedState=Z=e:Z=Z.next=e}return Z}function Wn(e,t){return typeof t=="function"?t(e):t}function $l(e){var t=_e(),n=t.queue;if(n===null)throw Error(g(311));n.lastRenderedReducer=e;var r=Y,l=r.baseQueue,o=n.pending;if(o!==null){if(l!==null){var i=l.next;l.next=o.next,o.next=i}r.baseQueue=l=o,n.pending=null}if(l!==null){o=l.next,r=r.baseState;var u=i=null,a=null,c=o;do{var v=c.lane;if((zt&v)===v)a!==null&&(a=a.next={lane:0,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null}),r=c.hasEagerState?c.eagerState:e(r,c.action);else{var m={lane:v,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null};a===null?(u=a=m,i=r):a=a.next=m,A.lanes|=v,Pt|=v}c=c.next}while(c!==null&&c!==o);a===null?i=r:a.next=u,De(r,t.memoizedState)||(ce=!0),t.memoizedState=r,t.baseState=i,t.baseQueue=a,n.lastRenderedState=r}if(e=n.interleaved,e!==null){l=e;do o=l.lane,A.lanes|=o,Pt|=o,l=l.next;while(l!==e)}else l===null&&(n.lanes=0);return[t.memoizedState,n.dispatch]}function Ul(e){var t=_e(),n=t.queue;if(n===null)throw Error(g(311));n.lastRenderedReducer=e;var r=n.dispatch,l=n.pending,o=t.memoizedState;if(l!==null){n.pending=null;var i=l=l.next;do o=e(o,i.action),i=i.next;while(i!==l);De(o,t.memoizedState)||(ce=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,r]}function is(){}function us(e,t){var n=A,r=_e(),l=t(),o=!De(r.memoizedState,l);if(o&&(r.memoizedState=l,ce=!0),r=r.queue,gi(cs.bind(null,n,r,e),[e]),r.getSnapshot!==t||o||Z!==null&&Z.memoizedState.tag&1){if(n.flags|=2048,Qn(9,ss.bind(null,n,r,l,t),void 0,null),J===null)throw Error(g(349));zt&30||as(n,t,l)}return l}function as(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=A.updateQueue,t===null?(t={lastEffect:null,stores:null},A.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function ss(e,t,n,r){t.value=n,t.getSnapshot=r,fs(t)&&ds(e)}function cs(e,t,n){return n(function(){fs(t)&&ds(e)})}function fs(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!De(e,n)}catch{return!0}}function ds(e){var t=Ke(e,1);t!==null&&Oe(t,e,1,-1)}function yu(e){var t=Fe();return typeof e=="function"&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Wn,lastRenderedState:e},t.queue=e,e=e.dispatch=qf.bind(null,A,e),[t.memoizedState,e]}function Qn(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},t=A.updateQueue,t===null?(t={lastEffect:null,stores:null},A.updateQueue=t,t.lastEffect=e.next=e):(n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e)),e}function ps(){return _e().memoizedState}function Cr(e,t,n,r){var l=Fe();A.flags|=e,l.memoizedState=Qn(1|t,n,void 0,r===void 0?null:r)}function il(e,t,n,r){var l=_e();r=r===void 0?null:r;var o=void 0;if(Y!==null){var i=Y.memoizedState;if(o=i.destroy,r!==null&&mi(r,i.deps)){l.memoizedState=Qn(t,n,o,r);return}}A.flags|=e,l.memoizedState=Qn(1|t,n,o,r)}function ku(e,t){return Cr(8390656,8,e,t)}function gi(e,t){return il(2048,8,e,t)}function ms(e,t){return il(4,2,e,t)}function vs(e,t){return il(4,4,e,t)}function hs(e,t){if(typeof t=="function")return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function gs(e,t,n){return n=n!=null?n.concat([e]):null,il(4,4,hs.bind(null,t,e),n)}function yi(){}function ys(e,t){var n=_e();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&mi(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function ks(e,t){var n=_e();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&mi(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function ws(e,t,n){return zt&21?(De(n,t)||(n=_a(),A.lanes|=n,Pt|=n,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,ce=!0),e.memoizedState=n)}function Zf(e,t){var n=D;D=n!==0&&4>n?n:4,e(!0);var r=jl.transition;jl.transition={};try{e(!1),t()}finally{D=n,jl.transition=r}}function xs(){return _e().memoizedState}function Jf(e,t,n){var r=at(e);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},Ss(e))Es(t,n);else if(n=rs(e,t,n,r),n!==null){var l=ie();Oe(n,e,r,l),Cs(n,t,r)}}function qf(e,t,n){var r=at(e),l={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(Ss(e))Es(t,l);else{var o=e.alternate;if(e.lanes===0&&(o===null||o.lanes===0)&&(o=t.lastRenderedReducer,o!==null))try{var i=t.lastRenderedState,u=o(i,n);if(l.hasEagerState=!0,l.eagerState=u,De(u,i)){var a=t.interleaved;a===null?(l.next=l,si(t)):(l.next=a.next,a.next=l),t.interleaved=l;return}}catch{}finally{}n=rs(e,t,l,r),n!==null&&(l=ie(),Oe(n,e,r,l),Cs(n,t,r))}}function Ss(e){var t=e.alternate;return e===A||t!==null&&t===A}function Es(e,t){zn=Kr=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function Cs(e,t,n){if(n&4194240){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Go(e,n)}}var Yr={readContext:Ce,useCallback:te,useContext:te,useEffect:te,useImperativeHandle:te,useInsertionEffect:te,useLayoutEffect:te,useMemo:te,useReducer:te,useRef:te,useState:te,useDebugValue:te,useDeferredValue:te,useTransition:te,useMutableSource:te,useSyncExternalStore:te,useId:te,unstable_isNewReconciler:!1},bf={readContext:Ce,useCallback:function(e,t){return Fe().memoizedState=[e,t===void 0?null:t],e},useContext:Ce,useEffect:ku,useImperativeHandle:function(e,t,n){return n=n!=null?n.concat([e]):null,Cr(4194308,4,hs.bind(null,t,e),n)},useLayoutEffect:function(e,t){return Cr(4194308,4,e,t)},useInsertionEffect:function(e,t){return Cr(4,2,e,t)},useMemo:function(e,t){var n=Fe();return t=t===void 0?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=Fe();return t=n!==void 0?n(t):t,r.memoizedState=r.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},r.queue=e,e=e.dispatch=Jf.bind(null,A,e),[r.memoizedState,e]},useRef:function(e){var t=Fe();return e={current:e},t.memoizedState=e},useState:yu,useDebugValue:yi,useDeferredValue:function(e){return Fe().memoizedState=e},useTransition:function(){var e=yu(!1),t=e[0];return e=Zf.bind(null,e[1]),Fe().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,n){var r=A,l=Fe();if($){if(n===void 0)throw Error(g(407));n=n()}else{if(n=t(),J===null)throw Error(g(349));zt&30||as(r,t,n)}l.memoizedState=n;var o={value:n,getSnapshot:t};return l.queue=o,ku(cs.bind(null,r,o,e),[e]),r.flags|=2048,Qn(9,ss.bind(null,r,o,n,t),void 0,null),n},useId:function(){var e=Fe(),t=J.identifierPrefix;if($){var n=Ve,r=Be;n=(r&~(1<<32-Re(r)-1)).toString(32)+n,t=":"+t+"R"+n,n=Hn++,0<n&&(t+="H"+n.toString(32)),t+=":"}else n=Gf++,t=":"+t+"r"+n.toString(32)+":";return e.memoizedState=t},unstable_isNewReconciler:!1},ed={readContext:Ce,useCallback:ys,useContext:Ce,useEffect:gi,useImperativeHandle:gs,useInsertionEffect:ms,useLayoutEffect:vs,useMemo:ks,useReducer:$l,useRef:ps,useState:function(){return $l(Wn)},useDebugValue:yi,useDeferredValue:function(e){var t=_e();return ws(t,Y.memoizedState,e)},useTransition:function(){var e=$l(Wn)[0],t=_e().memoizedState;return[e,t]},useMutableSource:is,useSyncExternalStore:us,useId:xs,unstable_isNewReconciler:!1},td={readContext:Ce,useCallback:ys,useContext:Ce,useEffect:gi,useImperativeHandle:gs,useInsertionEffect:ms,useLayoutEffect:vs,useMemo:ks,useReducer:Ul,useRef:ps,useState:function(){return Ul(Wn)},useDebugValue:yi,useDeferredValue:function(e){var t=_e();return Y===null?t.memoizedState=e:ws(t,Y.memoizedState,e)},useTransition:function(){var e=Ul(Wn)[0],t=_e().memoizedState;return[e,t]},useMutableSource:is,useSyncExternalStore:us,useId:xs,unstable_isNewReconciler:!1};function Ne(e,t){if(e&&e.defaultProps){t=B({},t),e=e.defaultProps;for(var n in e)t[n]===void 0&&(t[n]=e[n]);return t}return t}function xo(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:B({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var ul={isMounted:function(e){return(e=e._reactInternals)?Lt(e)===e:!1},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=ie(),l=at(e),o=He(r,l);o.payload=t,n!=null&&(o.callback=n),t=it(e,o,l),t!==null&&(Oe(t,e,l,r),Sr(t,e,l))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=ie(),l=at(e),o=He(r,l);o.tag=1,o.payload=t,n!=null&&(o.callback=n),t=it(e,o,l),t!==null&&(Oe(t,e,l,r),Sr(t,e,l))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=ie(),r=at(e),l=He(n,r);l.tag=2,t!=null&&(l.callback=t),t=it(e,l,r),t!==null&&(Oe(t,e,r,n),Sr(t,e,r))}};function wu(e,t,n,r,l,o,i){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(r,o,i):t.prototype&&t.prototype.isPureReactComponent?!jn(n,r)||!jn(l,o):!0}function _s(e,t,n){var r=!1,l=ft,o=t.contextType;return typeof o=="object"&&o!==null?o=Ce(o):(l=de(t)?Ct:le.current,r=t.contextTypes,o=(r=r!=null)?Jt(e,l):ft),t=new t(n,o),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=ul,e.stateNode=t,t._reactInternals=e,r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=l,e.__reactInternalMemoizedMaskedChildContext=o),t}function xu(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&ul.enqueueReplaceState(t,t.state,null)}function So(e,t,n,r){var l=e.stateNode;l.props=n,l.state=e.memoizedState,l.refs={},ci(e);var o=t.contextType;typeof o=="object"&&o!==null?l.context=Ce(o):(o=de(t)?Ct:le.current,l.context=Jt(e,o)),l.state=e.memoizedState,o=t.getDerivedStateFromProps,typeof o=="function"&&(xo(e,t,o,n),l.state=e.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof l.getSnapshotBeforeUpdate=="function"||typeof l.UNSAFE_componentWillMount!="function"&&typeof l.componentWillMount!="function"||(t=l.state,typeof l.componentWillMount=="function"&&l.componentWillMount(),typeof l.UNSAFE_componentWillMount=="function"&&l.UNSAFE_componentWillMount(),t!==l.state&&ul.enqueueReplaceState(l,l.state,null),Wr(e,n,l,r),l.state=e.memoizedState),typeof l.componentDidMount=="function"&&(e.flags|=4194308)}function tn(e,t){try{var n="",r=t;do n+=Nc(r),r=r.return;while(r);var l=n}catch(o){l=`
Error generating stack: `+o.message+`
`+o.stack}return{value:e,source:t,stack:l,digest:null}}function Al(e,t,n){return{value:e,source:null,stack:n??null,digest:t??null}}function Eo(e,t){try{console.error(t.value)}catch(n){setTimeout(function(){throw n})}}var nd=typeof WeakMap=="function"?WeakMap:Map;function zs(e,t,n){n=He(-1,n),n.tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){Gr||(Gr=!0,Do=r),Eo(e,t)},n}function Ps(e,t,n){n=He(-1,n),n.tag=3;var r=e.type.getDerivedStateFromError;if(typeof r=="function"){var l=t.value;n.payload=function(){return r(l)},n.callback=function(){Eo(e,t)}}var o=e.stateNode;return o!==null&&typeof o.componentDidCatch=="function"&&(n.callback=function(){Eo(e,t),typeof r!="function"&&(ut===null?ut=new Set([this]):ut.add(this));var i=t.stack;this.componentDidCatch(t.value,{componentStack:i!==null?i:""})}),n}function Su(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new nd;var l=new Set;r.set(t,l)}else l=r.get(t),l===void 0&&(l=new Set,r.set(t,l));l.has(n)||(l.add(n),e=hd.bind(null,e,t,n),t.then(e,e))}function Eu(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t!==null?t.dehydrated!==null:!0),t)return e;e=e.return}while(e!==null);return null}function Cu(e,t,n,r,l){return e.mode&1?(e.flags|=65536,e.lanes=l,e):(e===t?e.flags|=65536:(e.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(t=He(-1,1),t.tag=2,it(n,t,1))),n.lanes|=1),e)}var rd=Xe.ReactCurrentOwner,ce=!1;function oe(e,t,n,r){t.child=e===null?ns(t,null,n,r):bt(t,e.child,n,r)}function _u(e,t,n,r,l){n=n.render;var o=t.ref;return Xt(t,l),r=vi(e,t,n,r,o,l),n=hi(),e!==null&&!ce?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~l,Ye(e,t,l)):($&&n&&ri(t),t.flags|=1,oe(e,t,r,l),t.child)}function zu(e,t,n,r,l){if(e===null){var o=n.type;return typeof o=="function"&&!zi(o)&&o.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(t.tag=15,t.type=o,Ns(e,t,o,r,l)):(e=Nr(n.type,null,r,t,t.mode,l),e.ref=t.ref,e.return=t,t.child=e)}if(o=e.child,!(e.lanes&l)){var i=o.memoizedProps;if(n=n.compare,n=n!==null?n:jn,n(i,r)&&e.ref===t.ref)return Ye(e,t,l)}return t.flags|=1,e=st(o,r),e.ref=t.ref,e.return=t,t.child=e}function Ns(e,t,n,r,l){if(e!==null){var o=e.memoizedProps;if(jn(o,r)&&e.ref===t.ref)if(ce=!1,t.pendingProps=r=o,(e.lanes&l)!==0)e.flags&131072&&(ce=!0);else return t.lanes=e.lanes,Ye(e,t,l)}return Co(e,t,n,r,l)}function Ts(e,t,n){var r=t.pendingProps,l=r.children,o=e!==null?e.memoizedState:null;if(r.mode==="hidden")if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},M(Ht,me),me|=n;else{if(!(n&1073741824))return e=o!==null?o.baseLanes|n:n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,M(Ht,me),me|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=o!==null?o.baseLanes:n,M(Ht,me),me|=r}else o!==null?(r=o.baseLanes|n,t.memoizedState=null):r=n,M(Ht,me),me|=r;return oe(e,t,l,n),t.child}function Ls(e,t){var n=t.ref;(e===null&&n!==null||e!==null&&e.ref!==n)&&(t.flags|=512,t.flags|=2097152)}function Co(e,t,n,r,l){var o=de(n)?Ct:le.current;return o=Jt(t,o),Xt(t,l),n=vi(e,t,n,r,o,l),r=hi(),e!==null&&!ce?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~l,Ye(e,t,l)):($&&r&&ri(t),t.flags|=1,oe(e,t,n,l),t.child)}function Pu(e,t,n,r,l){if(de(n)){var o=!0;Ur(t)}else o=!1;if(Xt(t,l),t.stateNode===null)_r(e,t),_s(t,n,r),So(t,n,r,l),r=!0;else if(e===null){var i=t.stateNode,u=t.memoizedProps;i.props=u;var a=i.context,c=n.contextType;typeof c=="object"&&c!==null?c=Ce(c):(c=de(n)?Ct:le.current,c=Jt(t,c));var v=n.getDerivedStateFromProps,m=typeof v=="function"||typeof i.getSnapshotBeforeUpdate=="function";m||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(u!==r||a!==c)&&xu(t,i,r,c),Je=!1;var p=t.memoizedState;i.state=p,Wr(t,r,i,l),a=t.memoizedState,u!==r||p!==a||fe.current||Je?(typeof v=="function"&&(xo(t,n,v,r),a=t.memoizedState),(u=Je||wu(t,n,u,r,p,a,c))?(m||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount()),typeof i.componentDidMount=="function"&&(t.flags|=4194308)):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=a),i.props=r,i.state=a,i.context=c,r=u):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),r=!1)}else{i=t.stateNode,ls(e,t),u=t.memoizedProps,c=t.type===t.elementType?u:Ne(t.type,u),i.props=c,m=t.pendingProps,p=i.context,a=n.contextType,typeof a=="object"&&a!==null?a=Ce(a):(a=de(n)?Ct:le.current,a=Jt(t,a));var y=n.getDerivedStateFromProps;(v=typeof y=="function"||typeof i.getSnapshotBeforeUpdate=="function")||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(u!==m||p!==a)&&xu(t,i,r,a),Je=!1,p=t.memoizedState,i.state=p,Wr(t,r,i,l);var k=t.memoizedState;u!==m||p!==k||fe.current||Je?(typeof y=="function"&&(xo(t,n,y,r),k=t.memoizedState),(c=Je||wu(t,n,c,r,p,k,a)||!1)?(v||typeof i.UNSAFE_componentWillUpdate!="function"&&typeof i.componentWillUpdate!="function"||(typeof i.componentWillUpdate=="function"&&i.componentWillUpdate(r,k,a),typeof i.UNSAFE_componentWillUpdate=="function"&&i.UNSAFE_componentWillUpdate(r,k,a)),typeof i.componentDidUpdate=="function"&&(t.flags|=4),typeof i.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof i.componentDidUpdate!="function"||u===e.memoizedProps&&p===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||u===e.memoizedProps&&p===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=k),i.props=r,i.state=k,i.context=a,r=c):(typeof i.componentDidUpdate!="function"||u===e.memoizedProps&&p===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||u===e.memoizedProps&&p===e.memoizedState||(t.flags|=1024),r=!1)}return _o(e,t,n,r,o,l)}function _o(e,t,n,r,l,o){Ls(e,t);var i=(t.flags&128)!==0;if(!r&&!i)return l&&du(t,n,!1),Ye(e,t,o);r=t.stateNode,rd.current=t;var u=i&&typeof n.getDerivedStateFromError!="function"?null:r.render();return t.flags|=1,e!==null&&i?(t.child=bt(t,e.child,null,o),t.child=bt(t,null,u,o)):oe(e,t,u,o),t.memoizedState=r.state,l&&du(t,n,!0),t.child}function Rs(e){var t=e.stateNode;t.pendingContext?fu(e,t.pendingContext,t.pendingContext!==t.context):t.context&&fu(e,t.context,!1),fi(e,t.containerInfo)}function Nu(e,t,n,r,l){return qt(),oi(l),t.flags|=256,oe(e,t,n,r),t.child}var zo={dehydrated:null,treeContext:null,retryLane:0};function Po(e){return{baseLanes:e,cachePool:null,transitions:null}}function Os(e,t,n){var r=t.pendingProps,l=U.current,o=!1,i=(t.flags&128)!==0,u;if((u=i)||(u=e!==null&&e.memoizedState===null?!1:(l&2)!==0),u?(o=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(l|=1),M(U,l&1),e===null)return ko(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.mode&1?e.data==="$!"?t.lanes=8:t.lanes=1073741824:t.lanes=1,null):(i=r.children,e=r.fallback,o?(r=t.mode,o=t.child,i={mode:"hidden",children:i},!(r&1)&&o!==null?(o.childLanes=0,o.pendingProps=i):o=cl(i,r,0,null),e=Et(e,r,n,null),o.return=t,e.return=t,o.sibling=e,t.child=o,t.child.memoizedState=Po(n),t.memoizedState=zo,e):ki(t,i));if(l=e.memoizedState,l!==null&&(u=l.dehydrated,u!==null))return ld(e,t,i,r,u,l,n);if(o){o=r.fallback,i=t.mode,l=e.child,u=l.sibling;var a={mode:"hidden",children:r.children};return!(i&1)&&t.child!==l?(r=t.child,r.childLanes=0,r.pendingProps=a,t.deletions=null):(r=st(l,a),r.subtreeFlags=l.subtreeFlags&14680064),u!==null?o=st(u,o):(o=Et(o,i,n,null),o.flags|=2),o.return=t,r.return=t,r.sibling=o,t.child=r,r=o,o=t.child,i=e.child.memoizedState,i=i===null?Po(n):{baseLanes:i.baseLanes|n,cachePool:null,transitions:i.transitions},o.memoizedState=i,o.childLanes=e.childLanes&~n,t.memoizedState=zo,r}return o=e.child,e=o.sibling,r=st(o,{mode:"visible",children:r.children}),!(t.mode&1)&&(r.lanes=n),r.return=t,r.sibling=null,e!==null&&(n=t.deletions,n===null?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r}function ki(e,t){return t=cl({mode:"visible",children:t},e.mode,0,null),t.return=e,e.child=t}function pr(e,t,n,r){return r!==null&&oi(r),bt(t,e.child,null,n),e=ki(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function ld(e,t,n,r,l,o,i){if(n)return t.flags&256?(t.flags&=-257,r=Al(Error(g(422))),pr(e,t,i,r)):t.memoizedState!==null?(t.child=e.child,t.flags|=128,null):(o=r.fallback,l=t.mode,r=cl({mode:"visible",children:r.children},l,0,null),o=Et(o,l,i,null),o.flags|=2,r.return=t,o.return=t,r.sibling=o,t.child=r,t.mode&1&&bt(t,e.child,null,i),t.child.memoizedState=Po(i),t.memoizedState=zo,o);if(!(t.mode&1))return pr(e,t,i,null);if(l.data==="$!"){if(r=l.nextSibling&&l.nextSibling.dataset,r)var u=r.dgst;return r=u,o=Error(g(419)),r=Al(o,r,void 0),pr(e,t,i,r)}if(u=(i&e.childLanes)!==0,ce||u){if(r=J,r!==null){switch(i&-i){case 4:l=2;break;case 16:l=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:l=32;break;case 536870912:l=268435456;break;default:l=0}l=l&(r.suspendedLanes|i)?0:l,l!==0&&l!==o.retryLane&&(o.retryLane=l,Ke(e,l),Oe(r,e,l,-1))}return _i(),r=Al(Error(g(421))),pr(e,t,i,r)}return l.data==="$?"?(t.flags|=128,t.child=e.child,t=gd.bind(null,e),l._reactRetry=t,null):(e=o.treeContext,ve=ot(l.nextSibling),he=t,$=!0,Le=null,e!==null&&(we[xe++]=Be,we[xe++]=Ve,we[xe++]=_t,Be=e.id,Ve=e.overflow,_t=t),t=ki(t,r.children),t.flags|=4096,t)}function Tu(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),wo(e.return,t,n)}function Bl(e,t,n,r,l){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:l}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=l)}function Ds(e,t,n){var r=t.pendingProps,l=r.revealOrder,o=r.tail;if(oe(e,t,r.children,n),r=U.current,r&2)r=r&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Tu(e,n,t);else if(e.tag===19)Tu(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if(M(U,r),!(t.mode&1))t.memoizedState=null;else switch(l){case"forwards":for(n=t.child,l=null;n!==null;)e=n.alternate,e!==null&&Qr(e)===null&&(l=n),n=n.sibling;n=l,n===null?(l=t.child,t.child=null):(l=n.sibling,n.sibling=null),Bl(t,!1,l,n,o);break;case"backwards":for(n=null,l=t.child,t.child=null;l!==null;){if(e=l.alternate,e!==null&&Qr(e)===null){t.child=l;break}e=l.sibling,l.sibling=n,n=l,l=e}Bl(t,!0,n,null,o);break;case"together":Bl(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function _r(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function Ye(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Pt|=t.lanes,!(n&t.childLanes))return null;if(e!==null&&t.child!==e.child)throw Error(g(153));if(t.child!==null){for(e=t.child,n=st(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=st(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function od(e,t,n){switch(t.tag){case 3:Rs(t),qt();break;case 5:os(t);break;case 1:de(t.type)&&Ur(t);break;case 4:fi(t,t.stateNode.containerInfo);break;case 10:var r=t.type._context,l=t.memoizedProps.value;M(Vr,r._currentValue),r._currentValue=l;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated!==null?(M(U,U.current&1),t.flags|=128,null):n&t.child.childLanes?Os(e,t,n):(M(U,U.current&1),e=Ye(e,t,n),e!==null?e.sibling:null);M(U,U.current&1);break;case 19:if(r=(n&t.childLanes)!==0,e.flags&128){if(r)return Ds(e,t,n);t.flags|=128}if(l=t.memoizedState,l!==null&&(l.rendering=null,l.tail=null,l.lastEffect=null),M(U,U.current),r)break;return null;case 22:case 23:return t.lanes=0,Ts(e,t,n)}return Ye(e,t,n)}var Ms,No,Fs,Is;Ms=function(e,t){for(var n=t.child;n!==null;){if(n.tag===5||n.tag===6)e.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}};No=function(){};Fs=function(e,t,n,r){var l=e.memoizedProps;if(l!==r){e=t.stateNode,xt($e.current);var o=null;switch(n){case"input":l=Gl(e,l),r=Gl(e,r),o=[];break;case"select":l=B({},l,{value:void 0}),r=B({},r,{value:void 0}),o=[];break;case"textarea":l=ql(e,l),r=ql(e,r),o=[];break;default:typeof l.onClick!="function"&&typeof r.onClick=="function"&&(e.onclick=jr)}eo(n,r);var i;n=null;for(c in l)if(!r.hasOwnProperty(c)&&l.hasOwnProperty(c)&&l[c]!=null)if(c==="style"){var u=l[c];for(i in u)u.hasOwnProperty(i)&&(n||(n={}),n[i]="")}else c!=="dangerouslySetInnerHTML"&&c!=="children"&&c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&c!=="autoFocus"&&(Ln.hasOwnProperty(c)?o||(o=[]):(o=o||[]).push(c,null));for(c in r){var a=r[c];if(u=l!=null?l[c]:void 0,r.hasOwnProperty(c)&&a!==u&&(a!=null||u!=null))if(c==="style")if(u){for(i in u)!u.hasOwnProperty(i)||a&&a.hasOwnProperty(i)||(n||(n={}),n[i]="");for(i in a)a.hasOwnProperty(i)&&u[i]!==a[i]&&(n||(n={}),n[i]=a[i])}else n||(o||(o=[]),o.push(c,n)),n=a;else c==="dangerouslySetInnerHTML"?(a=a?a.__html:void 0,u=u?u.__html:void 0,a!=null&&u!==a&&(o=o||[]).push(c,a)):c==="children"?typeof a!="string"&&typeof a!="number"||(o=o||[]).push(c,""+a):c!=="suppressContentEditableWarning"&&c!=="suppressHydrationWarning"&&(Ln.hasOwnProperty(c)?(a!=null&&c==="onScroll"&&F("scroll",e),o||u===a||(o=[])):(o=o||[]).push(c,a))}n&&(o=o||[]).push("style",n);var c=o;(t.updateQueue=c)&&(t.flags|=4)}};Is=function(e,t,n,r){n!==r&&(t.flags|=4)};function vn(e,t){if(!$)switch(e.tailMode){case"hidden":t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case"collapsed":n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function ne(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var l=e.child;l!==null;)n|=l.lanes|l.childLanes,r|=l.subtreeFlags&14680064,r|=l.flags&14680064,l.return=e,l=l.sibling;else for(l=e.child;l!==null;)n|=l.lanes|l.childLanes,r|=l.subtreeFlags,r|=l.flags,l.return=e,l=l.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function id(e,t,n){var r=t.pendingProps;switch(li(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return ne(t),null;case 1:return de(t.type)&&$r(),ne(t),null;case 3:return r=t.stateNode,en(),I(fe),I(le),pi(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(fr(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,Le!==null&&(Io(Le),Le=null))),No(e,t),ne(t),null;case 5:di(t);var l=xt(Vn.current);if(n=t.type,e!==null&&t.stateNode!=null)Fs(e,t,n,r,l),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!r){if(t.stateNode===null)throw Error(g(166));return ne(t),null}if(e=xt($e.current),fr(t)){r=t.stateNode,n=t.type;var o=t.memoizedProps;switch(r[Ie]=t,r[An]=o,e=(t.mode&1)!==0,n){case"dialog":F("cancel",r),F("close",r);break;case"iframe":case"object":case"embed":F("load",r);break;case"video":case"audio":for(l=0;l<wn.length;l++)F(wn[l],r);break;case"source":F("error",r);break;case"img":case"image":case"link":F("error",r),F("load",r);break;case"details":F("toggle",r);break;case"input":$i(r,o),F("invalid",r);break;case"select":r._wrapperState={wasMultiple:!!o.multiple},F("invalid",r);break;case"textarea":Ai(r,o),F("invalid",r)}eo(n,o),l=null;for(var i in o)if(o.hasOwnProperty(i)){var u=o[i];i==="children"?typeof u=="string"?r.textContent!==u&&(o.suppressHydrationWarning!==!0&&cr(r.textContent,u,e),l=["children",u]):typeof u=="number"&&r.textContent!==""+u&&(o.suppressHydrationWarning!==!0&&cr(r.textContent,u,e),l=["children",""+u]):Ln.hasOwnProperty(i)&&u!=null&&i==="onScroll"&&F("scroll",r)}switch(n){case"input":nr(r),Ui(r,o,!0);break;case"textarea":nr(r),Bi(r);break;case"select":case"option":break;default:typeof o.onClick=="function"&&(r.onclick=jr)}r=l,t.updateQueue=r,r!==null&&(t.flags|=4)}else{i=l.nodeType===9?l:l.ownerDocument,e==="http://www.w3.org/1999/xhtml"&&(e=ca(n)),e==="http://www.w3.org/1999/xhtml"?n==="script"?(e=i.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):typeof r.is=="string"?e=i.createElement(n,{is:r.is}):(e=i.createElement(n),n==="select"&&(i=e,r.multiple?i.multiple=!0:r.size&&(i.size=r.size))):e=i.createElementNS(e,n),e[Ie]=t,e[An]=r,Ms(e,t,!1,!1),t.stateNode=e;e:{switch(i=to(n,r),n){case"dialog":F("cancel",e),F("close",e),l=r;break;case"iframe":case"object":case"embed":F("load",e),l=r;break;case"video":case"audio":for(l=0;l<wn.length;l++)F(wn[l],e);l=r;break;case"source":F("error",e),l=r;break;case"img":case"image":case"link":F("error",e),F("load",e),l=r;break;case"details":F("toggle",e),l=r;break;case"input":$i(e,r),l=Gl(e,r),F("invalid",e);break;case"option":l=r;break;case"select":e._wrapperState={wasMultiple:!!r.multiple},l=B({},r,{value:void 0}),F("invalid",e);break;case"textarea":Ai(e,r),l=ql(e,r),F("invalid",e);break;default:l=r}eo(n,l),u=l;for(o in u)if(u.hasOwnProperty(o)){var a=u[o];o==="style"?pa(e,a):o==="dangerouslySetInnerHTML"?(a=a?a.__html:void 0,a!=null&&fa(e,a)):o==="children"?typeof a=="string"?(n!=="textarea"||a!=="")&&Rn(e,a):typeof a=="number"&&Rn(e,""+a):o!=="suppressContentEditableWarning"&&o!=="suppressHydrationWarning"&&o!=="autoFocus"&&(Ln.hasOwnProperty(o)?a!=null&&o==="onScroll"&&F("scroll",e):a!=null&&Ho(e,o,a,i))}switch(n){case"input":nr(e),Ui(e,r,!1);break;case"textarea":nr(e),Bi(e);break;case"option":r.value!=null&&e.setAttribute("value",""+ct(r.value));break;case"select":e.multiple=!!r.multiple,o=r.value,o!=null?Wt(e,!!r.multiple,o,!1):r.defaultValue!=null&&Wt(e,!!r.multiple,r.defaultValue,!0);break;default:typeof l.onClick=="function"&&(e.onclick=jr)}switch(n){case"button":case"input":case"select":case"textarea":r=!!r.autoFocus;break e;case"img":r=!0;break e;default:r=!1}}r&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return ne(t),null;case 6:if(e&&t.stateNode!=null)Is(e,t,e.memoizedProps,r);else{if(typeof r!="string"&&t.stateNode===null)throw Error(g(166));if(n=xt(Vn.current),xt($e.current),fr(t)){if(r=t.stateNode,n=t.memoizedProps,r[Ie]=t,(o=r.nodeValue!==n)&&(e=he,e!==null))switch(e.tag){case 3:cr(r.nodeValue,n,(e.mode&1)!==0);break;case 5:e.memoizedProps.suppressHydrationWarning!==!0&&cr(r.nodeValue,n,(e.mode&1)!==0)}o&&(t.flags|=4)}else r=(n.nodeType===9?n:n.ownerDocument).createTextNode(r),r[Ie]=t,t.stateNode=r}return ne(t),null;case 13:if(I(U),r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if($&&ve!==null&&t.mode&1&&!(t.flags&128))es(),qt(),t.flags|=98560,o=!1;else if(o=fr(t),r!==null&&r.dehydrated!==null){if(e===null){if(!o)throw Error(g(318));if(o=t.memoizedState,o=o!==null?o.dehydrated:null,!o)throw Error(g(317));o[Ie]=t}else qt(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;ne(t),o=!1}else Le!==null&&(Io(Le),Le=null),o=!0;if(!o)return t.flags&65536?t:null}return t.flags&128?(t.lanes=n,t):(r=r!==null,r!==(e!==null&&e.memoizedState!==null)&&r&&(t.child.flags|=8192,t.mode&1&&(e===null||U.current&1?X===0&&(X=3):_i())),t.updateQueue!==null&&(t.flags|=4),ne(t),null);case 4:return en(),No(e,t),e===null&&$n(t.stateNode.containerInfo),ne(t),null;case 10:return ai(t.type._context),ne(t),null;case 17:return de(t.type)&&$r(),ne(t),null;case 19:if(I(U),o=t.memoizedState,o===null)return ne(t),null;if(r=(t.flags&128)!==0,i=o.rendering,i===null)if(r)vn(o,!1);else{if(X!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(i=Qr(e),i!==null){for(t.flags|=128,vn(o,!1),r=i.updateQueue,r!==null&&(t.updateQueue=r,t.flags|=4),t.subtreeFlags=0,r=n,n=t.child;n!==null;)o=n,e=r,o.flags&=14680066,i=o.alternate,i===null?(o.childLanes=0,o.lanes=e,o.child=null,o.subtreeFlags=0,o.memoizedProps=null,o.memoizedState=null,o.updateQueue=null,o.dependencies=null,o.stateNode=null):(o.childLanes=i.childLanes,o.lanes=i.lanes,o.child=i.child,o.subtreeFlags=0,o.deletions=null,o.memoizedProps=i.memoizedProps,o.memoizedState=i.memoizedState,o.updateQueue=i.updateQueue,o.type=i.type,e=i.dependencies,o.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return M(U,U.current&1|2),t.child}e=e.sibling}o.tail!==null&&Q()>nn&&(t.flags|=128,r=!0,vn(o,!1),t.lanes=4194304)}else{if(!r)if(e=Qr(i),e!==null){if(t.flags|=128,r=!0,n=e.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),vn(o,!0),o.tail===null&&o.tailMode==="hidden"&&!i.alternate&&!$)return ne(t),null}else 2*Q()-o.renderingStartTime>nn&&n!==1073741824&&(t.flags|=128,r=!0,vn(o,!1),t.lanes=4194304);o.isBackwards?(i.sibling=t.child,t.child=i):(n=o.last,n!==null?n.sibling=i:t.child=i,o.last=i)}return o.tail!==null?(t=o.tail,o.rendering=t,o.tail=t.sibling,o.renderingStartTime=Q(),t.sibling=null,n=U.current,M(U,r?n&1|2:n&1),t):(ne(t),null);case 22:case 23:return Ci(),r=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==r&&(t.flags|=8192),r&&t.mode&1?me&1073741824&&(ne(t),t.subtreeFlags&6&&(t.flags|=8192)):ne(t),null;case 24:return null;case 25:return null}throw Error(g(156,t.tag))}function ud(e,t){switch(li(t),t.tag){case 1:return de(t.type)&&$r(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return en(),I(fe),I(le),pi(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return di(t),null;case 13:if(I(U),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(g(340));qt()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return I(U),null;case 4:return en(),null;case 10:return ai(t.type._context),null;case 22:case 23:return Ci(),null;case 24:return null;default:return null}}var mr=!1,re=!1,ad=typeof WeakSet=="function"?WeakSet:Set,x=null;function Vt(e,t){var n=e.ref;if(n!==null)if(typeof n=="function")try{n(null)}catch(r){V(e,t,r)}else n.current=null}function To(e,t,n){try{n()}catch(r){V(e,t,r)}}var Lu=!1;function sd(e,t){if(fo=Mr,e=Ba(),ni(e)){if("selectionStart"in e)var n={start:e.selectionStart,end:e.selectionEnd};else e:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var l=r.anchorOffset,o=r.focusNode;r=r.focusOffset;try{n.nodeType,o.nodeType}catch{n=null;break e}var i=0,u=-1,a=-1,c=0,v=0,m=e,p=null;t:for(;;){for(var y;m!==n||l!==0&&m.nodeType!==3||(u=i+l),m!==o||r!==0&&m.nodeType!==3||(a=i+r),m.nodeType===3&&(i+=m.nodeValue.length),(y=m.firstChild)!==null;)p=m,m=y;for(;;){if(m===e)break t;if(p===n&&++c===l&&(u=i),p===o&&++v===r&&(a=i),(y=m.nextSibling)!==null)break;m=p,p=m.parentNode}m=y}n=u===-1||a===-1?null:{start:u,end:a}}else n=null}n=n||{start:0,end:0}}else n=null;for(po={focusedElem:e,selectionRange:n},Mr=!1,x=t;x!==null;)if(t=x,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,x=e;else for(;x!==null;){t=x;try{var k=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(k!==null){var w=k.memoizedProps,j=k.memoizedState,f=t.stateNode,s=f.getSnapshotBeforeUpdate(t.elementType===t.type?w:Ne(t.type,w),j);f.__reactInternalSnapshotBeforeUpdate=s}break;case 3:var d=t.stateNode.containerInfo;d.nodeType===1?d.textContent="":d.nodeType===9&&d.documentElement&&d.removeChild(d.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(g(163))}}catch(h){V(t,t.return,h)}if(e=t.sibling,e!==null){e.return=t.return,x=e;break}x=t.return}return k=Lu,Lu=!1,k}function Pn(e,t,n){var r=t.updateQueue;if(r=r!==null?r.lastEffect:null,r!==null){var l=r=r.next;do{if((l.tag&e)===e){var o=l.destroy;l.destroy=void 0,o!==void 0&&To(t,n,o)}l=l.next}while(l!==r)}}function al(e,t){if(t=t.updateQueue,t=t!==null?t.lastEffect:null,t!==null){var n=t=t.next;do{if((n.tag&e)===e){var r=n.create;n.destroy=r()}n=n.next}while(n!==t)}}function Lo(e){var t=e.ref;if(t!==null){var n=e.stateNode;switch(e.tag){case 5:e=n;break;default:e=n}typeof t=="function"?t(e):t.current=e}}function js(e){var t=e.alternate;t!==null&&(e.alternate=null,js(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[Ie],delete t[An],delete t[ho],delete t[Qf],delete t[Kf])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function $s(e){return e.tag===5||e.tag===3||e.tag===4}function Ru(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||$s(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Ro(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.nodeType===8?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(n.nodeType===8?(t=n.parentNode,t.insertBefore(e,n)):(t=n,t.appendChild(e)),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=jr));else if(r!==4&&(e=e.child,e!==null))for(Ro(e,t,n),e=e.sibling;e!==null;)Ro(e,t,n),e=e.sibling}function Oo(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(e=e.child,e!==null))for(Oo(e,t,n),e=e.sibling;e!==null;)Oo(e,t,n),e=e.sibling}var q=null,Te=!1;function Ge(e,t,n){for(n=n.child;n!==null;)Us(e,t,n),n=n.sibling}function Us(e,t,n){if(je&&typeof je.onCommitFiberUnmount=="function")try{je.onCommitFiberUnmount(el,n)}catch{}switch(n.tag){case 5:re||Vt(n,t);case 6:var r=q,l=Te;q=null,Ge(e,t,n),q=r,Te=l,q!==null&&(Te?(e=q,n=n.stateNode,e.nodeType===8?e.parentNode.removeChild(n):e.removeChild(n)):q.removeChild(n.stateNode));break;case 18:q!==null&&(Te?(e=q,n=n.stateNode,e.nodeType===8?Ml(e.parentNode,n):e.nodeType===1&&Ml(e,n),Fn(e)):Ml(q,n.stateNode));break;case 4:r=q,l=Te,q=n.stateNode.containerInfo,Te=!0,Ge(e,t,n),q=r,Te=l;break;case 0:case 11:case 14:case 15:if(!re&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){l=r=r.next;do{var o=l,i=o.destroy;o=o.tag,i!==void 0&&(o&2||o&4)&&To(n,t,i),l=l.next}while(l!==r)}Ge(e,t,n);break;case 1:if(!re&&(Vt(n,t),r=n.stateNode,typeof r.componentWillUnmount=="function"))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(u){V(n,t,u)}Ge(e,t,n);break;case 21:Ge(e,t,n);break;case 22:n.mode&1?(re=(r=re)||n.memoizedState!==null,Ge(e,t,n),re=r):Ge(e,t,n);break;default:Ge(e,t,n)}}function Ou(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var n=e.stateNode;n===null&&(n=e.stateNode=new ad),t.forEach(function(r){var l=yd.bind(null,e,r);n.has(r)||(n.add(r),r.then(l,l))})}}function Pe(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var l=n[r];try{var o=e,i=t,u=i;e:for(;u!==null;){switch(u.tag){case 5:q=u.stateNode,Te=!1;break e;case 3:q=u.stateNode.containerInfo,Te=!0;break e;case 4:q=u.stateNode.containerInfo,Te=!0;break e}u=u.return}if(q===null)throw Error(g(160));Us(o,i,l),q=null,Te=!1;var a=l.alternate;a!==null&&(a.return=null),l.return=null}catch(c){V(l,t,c)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)As(t,e),t=t.sibling}function As(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(Pe(t,e),Me(e),r&4){try{Pn(3,e,e.return),al(3,e)}catch(w){V(e,e.return,w)}try{Pn(5,e,e.return)}catch(w){V(e,e.return,w)}}break;case 1:Pe(t,e),Me(e),r&512&&n!==null&&Vt(n,n.return);break;case 5:if(Pe(t,e),Me(e),r&512&&n!==null&&Vt(n,n.return),e.flags&32){var l=e.stateNode;try{Rn(l,"")}catch(w){V(e,e.return,w)}}if(r&4&&(l=e.stateNode,l!=null)){var o=e.memoizedProps,i=n!==null?n.memoizedProps:o,u=e.type,a=e.updateQueue;if(e.updateQueue=null,a!==null)try{u==="input"&&o.type==="radio"&&o.name!=null&&aa(l,o),to(u,i);var c=to(u,o);for(i=0;i<a.length;i+=2){var v=a[i],m=a[i+1];v==="style"?pa(l,m):v==="dangerouslySetInnerHTML"?fa(l,m):v==="children"?Rn(l,m):Ho(l,v,m,c)}switch(u){case"input":Zl(l,o);break;case"textarea":sa(l,o);break;case"select":var p=l._wrapperState.wasMultiple;l._wrapperState.wasMultiple=!!o.multiple;var y=o.value;y!=null?Wt(l,!!o.multiple,y,!1):p!==!!o.multiple&&(o.defaultValue!=null?Wt(l,!!o.multiple,o.defaultValue,!0):Wt(l,!!o.multiple,o.multiple?[]:"",!1))}l[An]=o}catch(w){V(e,e.return,w)}}break;case 6:if(Pe(t,e),Me(e),r&4){if(e.stateNode===null)throw Error(g(162));l=e.stateNode,o=e.memoizedProps;try{l.nodeValue=o}catch(w){V(e,e.return,w)}}break;case 3:if(Pe(t,e),Me(e),r&4&&n!==null&&n.memoizedState.isDehydrated)try{Fn(t.containerInfo)}catch(w){V(e,e.return,w)}break;case 4:Pe(t,e),Me(e);break;case 13:Pe(t,e),Me(e),l=e.child,l.flags&8192&&(o=l.memoizedState!==null,l.stateNode.isHidden=o,!o||l.alternate!==null&&l.alternate.memoizedState!==null||(Si=Q())),r&4&&Ou(e);break;case 22:if(v=n!==null&&n.memoizedState!==null,e.mode&1?(re=(c=re)||v,Pe(t,e),re=c):Pe(t,e),Me(e),r&8192){if(c=e.memoizedState!==null,(e.stateNode.isHidden=c)&&!v&&e.mode&1)for(x=e,v=e.child;v!==null;){for(m=x=v;x!==null;){switch(p=x,y=p.child,p.tag){case 0:case 11:case 14:case 15:Pn(4,p,p.return);break;case 1:Vt(p,p.return);var k=p.stateNode;if(typeof k.componentWillUnmount=="function"){r=p,n=p.return;try{t=r,k.props=t.memoizedProps,k.state=t.memoizedState,k.componentWillUnmount()}catch(w){V(r,n,w)}}break;case 5:Vt(p,p.return);break;case 22:if(p.memoizedState!==null){Mu(m);continue}}y!==null?(y.return=p,x=y):Mu(m)}v=v.sibling}e:for(v=null,m=e;;){if(m.tag===5){if(v===null){v=m;try{l=m.stateNode,c?(o=l.style,typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"):(u=m.stateNode,a=m.memoizedProps.style,i=a!=null&&a.hasOwnProperty("display")?a.display:null,u.style.display=da("display",i))}catch(w){V(e,e.return,w)}}}else if(m.tag===6){if(v===null)try{m.stateNode.nodeValue=c?"":m.memoizedProps}catch(w){V(e,e.return,w)}}else if((m.tag!==22&&m.tag!==23||m.memoizedState===null||m===e)&&m.child!==null){m.child.return=m,m=m.child;continue}if(m===e)break e;for(;m.sibling===null;){if(m.return===null||m.return===e)break e;v===m&&(v=null),m=m.return}v===m&&(v=null),m.sibling.return=m.return,m=m.sibling}}break;case 19:Pe(t,e),Me(e),r&4&&Ou(e);break;case 21:break;default:Pe(t,e),Me(e)}}function Me(e){var t=e.flags;if(t&2){try{e:{for(var n=e.return;n!==null;){if($s(n)){var r=n;break e}n=n.return}throw Error(g(160))}switch(r.tag){case 5:var l=r.stateNode;r.flags&32&&(Rn(l,""),r.flags&=-33);var o=Ru(e);Oo(e,o,l);break;case 3:case 4:var i=r.stateNode.containerInfo,u=Ru(e);Ro(e,u,i);break;default:throw Error(g(161))}}catch(a){V(e,e.return,a)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function cd(e,t,n){x=e,Bs(e)}function Bs(e,t,n){for(var r=(e.mode&1)!==0;x!==null;){var l=x,o=l.child;if(l.tag===22&&r){var i=l.memoizedState!==null||mr;if(!i){var u=l.alternate,a=u!==null&&u.memoizedState!==null||re;u=mr;var c=re;if(mr=i,(re=a)&&!c)for(x=l;x!==null;)i=x,a=i.child,i.tag===22&&i.memoizedState!==null?Fu(l):a!==null?(a.return=i,x=a):Fu(l);for(;o!==null;)x=o,Bs(o),o=o.sibling;x=l,mr=u,re=c}Du(e)}else l.subtreeFlags&8772&&o!==null?(o.return=l,x=o):Du(e)}}function Du(e){for(;x!==null;){var t=x;if(t.flags&8772){var n=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:re||al(5,t);break;case 1:var r=t.stateNode;if(t.flags&4&&!re)if(n===null)r.componentDidMount();else{var l=t.elementType===t.type?n.memoizedProps:Ne(t.type,n.memoizedProps);r.componentDidUpdate(l,n.memoizedState,r.__reactInternalSnapshotBeforeUpdate)}var o=t.updateQueue;o!==null&&gu(t,o,r);break;case 3:var i=t.updateQueue;if(i!==null){if(n=null,t.child!==null)switch(t.child.tag){case 5:n=t.child.stateNode;break;case 1:n=t.child.stateNode}gu(t,i,n)}break;case 5:var u=t.stateNode;if(n===null&&t.flags&4){n=u;var a=t.memoizedProps;switch(t.type){case"button":case"input":case"select":case"textarea":a.autoFocus&&n.focus();break;case"img":a.src&&(n.src=a.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var c=t.alternate;if(c!==null){var v=c.memoizedState;if(v!==null){var m=v.dehydrated;m!==null&&Fn(m)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(g(163))}re||t.flags&512&&Lo(t)}catch(p){V(t,t.return,p)}}if(t===e){x=null;break}if(n=t.sibling,n!==null){n.return=t.return,x=n;break}x=t.return}}function Mu(e){for(;x!==null;){var t=x;if(t===e){x=null;break}var n=t.sibling;if(n!==null){n.return=t.return,x=n;break}x=t.return}}function Fu(e){for(;x!==null;){var t=x;try{switch(t.tag){case 0:case 11:case 15:var n=t.return;try{al(4,t)}catch(a){V(t,n,a)}break;case 1:var r=t.stateNode;if(typeof r.componentDidMount=="function"){var l=t.return;try{r.componentDidMount()}catch(a){V(t,l,a)}}var o=t.return;try{Lo(t)}catch(a){V(t,o,a)}break;case 5:var i=t.return;try{Lo(t)}catch(a){V(t,i,a)}}}catch(a){V(t,t.return,a)}if(t===e){x=null;break}var u=t.sibling;if(u!==null){u.return=t.return,x=u;break}x=t.return}}var fd=Math.ceil,Xr=Xe.ReactCurrentDispatcher,wi=Xe.ReactCurrentOwner,Ee=Xe.ReactCurrentBatchConfig,O=0,J=null,K=null,b=0,me=0,Ht=pt(0),X=0,Kn=null,Pt=0,sl=0,xi=0,Nn=null,se=null,Si=0,nn=1/0,Ue=null,Gr=!1,Do=null,ut=null,vr=!1,tt=null,Zr=0,Tn=0,Mo=null,zr=-1,Pr=0;function ie(){return O&6?Q():zr!==-1?zr:zr=Q()}function at(e){return e.mode&1?O&2&&b!==0?b&-b:Xf.transition!==null?(Pr===0&&(Pr=_a()),Pr):(e=D,e!==0||(e=window.event,e=e===void 0?16:Oa(e.type)),e):1}function Oe(e,t,n,r){if(50<Tn)throw Tn=0,Mo=null,Error(g(185));Xn(e,n,r),(!(O&2)||e!==J)&&(e===J&&(!(O&2)&&(sl|=n),X===4&&be(e,b)),pe(e,r),n===1&&O===0&&!(t.mode&1)&&(nn=Q()+500,ol&&mt()))}function pe(e,t){var n=e.callbackNode;Yc(e,t);var r=Dr(e,e===J?b:0);if(r===0)n!==null&&Wi(n),e.callbackNode=null,e.callbackPriority=0;else if(t=r&-r,e.callbackPriority!==t){if(n!=null&&Wi(n),t===1)e.tag===0?Yf(Iu.bind(null,e)):Ja(Iu.bind(null,e)),Hf(function(){!(O&6)&&mt()}),n=null;else{switch(za(r)){case 1:n=Xo;break;case 4:n=Ea;break;case 16:n=Or;break;case 536870912:n=Ca;break;default:n=Or}n=Gs(n,Vs.bind(null,e))}e.callbackPriority=t,e.callbackNode=n}}function Vs(e,t){if(zr=-1,Pr=0,O&6)throw Error(g(327));var n=e.callbackNode;if(Gt()&&e.callbackNode!==n)return null;var r=Dr(e,e===J?b:0);if(r===0)return null;if(r&30||r&e.expiredLanes||t)t=Jr(e,r);else{t=r;var l=O;O|=2;var o=Ws();(J!==e||b!==t)&&(Ue=null,nn=Q()+500,St(e,t));do try{md();break}catch(u){Hs(e,u)}while(!0);ui(),Xr.current=o,O=l,K!==null?t=0:(J=null,b=0,t=X)}if(t!==0){if(t===2&&(l=io(e),l!==0&&(r=l,t=Fo(e,l))),t===1)throw n=Kn,St(e,0),be(e,r),pe(e,Q()),n;if(t===6)be(e,r);else{if(l=e.current.alternate,!(r&30)&&!dd(l)&&(t=Jr(e,r),t===2&&(o=io(e),o!==0&&(r=o,t=Fo(e,o))),t===1))throw n=Kn,St(e,0),be(e,r),pe(e,Q()),n;switch(e.finishedWork=l,e.finishedLanes=r,t){case 0:case 1:throw Error(g(345));case 2:yt(e,se,Ue);break;case 3:if(be(e,r),(r&130023424)===r&&(t=Si+500-Q(),10<t)){if(Dr(e,0)!==0)break;if(l=e.suspendedLanes,(l&r)!==r){ie(),e.pingedLanes|=e.suspendedLanes&l;break}e.timeoutHandle=vo(yt.bind(null,e,se,Ue),t);break}yt(e,se,Ue);break;case 4:if(be(e,r),(r&4194240)===r)break;for(t=e.eventTimes,l=-1;0<r;){var i=31-Re(r);o=1<<i,i=t[i],i>l&&(l=i),r&=~o}if(r=l,r=Q()-r,r=(120>r?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*fd(r/1960))-r,10<r){e.timeoutHandle=vo(yt.bind(null,e,se,Ue),r);break}yt(e,se,Ue);break;case 5:yt(e,se,Ue);break;default:throw Error(g(329))}}}return pe(e,Q()),e.callbackNode===n?Vs.bind(null,e):null}function Fo(e,t){var n=Nn;return e.current.memoizedState.isDehydrated&&(St(e,t).flags|=256),e=Jr(e,t),e!==2&&(t=se,se=n,t!==null&&Io(t)),e}function Io(e){se===null?se=e:se.push.apply(se,e)}function dd(e){for(var t=e;;){if(t.flags&16384){var n=t.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var l=n[r],o=l.getSnapshot;l=l.value;try{if(!De(o(),l))return!1}catch{return!1}}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function be(e,t){for(t&=~xi,t&=~sl,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-Re(t),r=1<<n;e[n]=-1,t&=~r}}function Iu(e){if(O&6)throw Error(g(327));Gt();var t=Dr(e,0);if(!(t&1))return pe(e,Q()),null;var n=Jr(e,t);if(e.tag!==0&&n===2){var r=io(e);r!==0&&(t=r,n=Fo(e,r))}if(n===1)throw n=Kn,St(e,0),be(e,t),pe(e,Q()),n;if(n===6)throw Error(g(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,yt(e,se,Ue),pe(e,Q()),null}function Ei(e,t){var n=O;O|=1;try{return e(t)}finally{O=n,O===0&&(nn=Q()+500,ol&&mt())}}function Nt(e){tt!==null&&tt.tag===0&&!(O&6)&&Gt();var t=O;O|=1;var n=Ee.transition,r=D;try{if(Ee.transition=null,D=1,e)return e()}finally{D=r,Ee.transition=n,O=t,!(O&6)&&mt()}}function Ci(){me=Ht.current,I(Ht)}function St(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(n!==-1&&(e.timeoutHandle=-1,Vf(n)),K!==null)for(n=K.return;n!==null;){var r=n;switch(li(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&$r();break;case 3:en(),I(fe),I(le),pi();break;case 5:di(r);break;case 4:en();break;case 13:I(U);break;case 19:I(U);break;case 10:ai(r.type._context);break;case 22:case 23:Ci()}n=n.return}if(J=e,K=e=st(e.current,null),b=me=t,X=0,Kn=null,xi=sl=Pt=0,se=Nn=null,wt!==null){for(t=0;t<wt.length;t++)if(n=wt[t],r=n.interleaved,r!==null){n.interleaved=null;var l=r.next,o=n.pending;if(o!==null){var i=o.next;o.next=l,r.next=i}n.pending=r}wt=null}return e}function Hs(e,t){do{var n=K;try{if(ui(),Er.current=Yr,Kr){for(var r=A.memoizedState;r!==null;){var l=r.queue;l!==null&&(l.pending=null),r=r.next}Kr=!1}if(zt=0,Z=Y=A=null,zn=!1,Hn=0,wi.current=null,n===null||n.return===null){X=1,Kn=t,K=null;break}e:{var o=e,i=n.return,u=n,a=t;if(t=b,u.flags|=32768,a!==null&&typeof a=="object"&&typeof a.then=="function"){var c=a,v=u,m=v.tag;if(!(v.mode&1)&&(m===0||m===11||m===15)){var p=v.alternate;p?(v.updateQueue=p.updateQueue,v.memoizedState=p.memoizedState,v.lanes=p.lanes):(v.updateQueue=null,v.memoizedState=null)}var y=Eu(i);if(y!==null){y.flags&=-257,Cu(y,i,u,o,t),y.mode&1&&Su(o,c,t),t=y,a=c;var k=t.updateQueue;if(k===null){var w=new Set;w.add(a),t.updateQueue=w}else k.add(a);break e}else{if(!(t&1)){Su(o,c,t),_i();break e}a=Error(g(426))}}else if($&&u.mode&1){var j=Eu(i);if(j!==null){!(j.flags&65536)&&(j.flags|=256),Cu(j,i,u,o,t),oi(tn(a,u));break e}}o=a=tn(a,u),X!==4&&(X=2),Nn===null?Nn=[o]:Nn.push(o),o=i;do{switch(o.tag){case 3:o.flags|=65536,t&=-t,o.lanes|=t;var f=zs(o,a,t);hu(o,f);break e;case 1:u=a;var s=o.type,d=o.stateNode;if(!(o.flags&128)&&(typeof s.getDerivedStateFromError=="function"||d!==null&&typeof d.componentDidCatch=="function"&&(ut===null||!ut.has(d)))){o.flags|=65536,t&=-t,o.lanes|=t;var h=Ps(o,u,t);hu(o,h);break e}}o=o.return}while(o!==null)}Ks(n)}catch(S){t=S,K===n&&n!==null&&(K=n=n.return);continue}break}while(!0)}function Ws(){var e=Xr.current;return Xr.current=Yr,e===null?Yr:e}function _i(){(X===0||X===3||X===2)&&(X=4),J===null||!(Pt&268435455)&&!(sl&268435455)||be(J,b)}function Jr(e,t){var n=O;O|=2;var r=Ws();(J!==e||b!==t)&&(Ue=null,St(e,t));do try{pd();break}catch(l){Hs(e,l)}while(!0);if(ui(),O=n,Xr.current=r,K!==null)throw Error(g(261));return J=null,b=0,X}function pd(){for(;K!==null;)Qs(K)}function md(){for(;K!==null&&!$c();)Qs(K)}function Qs(e){var t=Xs(e.alternate,e,me);e.memoizedProps=e.pendingProps,t===null?Ks(e):K=t,wi.current=null}function Ks(e){var t=e;do{var n=t.alternate;if(e=t.return,t.flags&32768){if(n=ud(n,t),n!==null){n.flags&=32767,K=n;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{X=6,K=null;return}}else if(n=id(n,t,me),n!==null){K=n;return}if(t=t.sibling,t!==null){K=t;return}K=t=e}while(t!==null);X===0&&(X=5)}function yt(e,t,n){var r=D,l=Ee.transition;try{Ee.transition=null,D=1,vd(e,t,n,r)}finally{Ee.transition=l,D=r}return null}function vd(e,t,n,r){do Gt();while(tt!==null);if(O&6)throw Error(g(327));n=e.finishedWork;var l=e.finishedLanes;if(n===null)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(g(177));e.callbackNode=null,e.callbackPriority=0;var o=n.lanes|n.childLanes;if(Xc(e,o),e===J&&(K=J=null,b=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||vr||(vr=!0,Gs(Or,function(){return Gt(),null})),o=(n.flags&15990)!==0,n.subtreeFlags&15990||o){o=Ee.transition,Ee.transition=null;var i=D;D=1;var u=O;O|=4,wi.current=null,sd(e,n),As(n,e),Ff(po),Mr=!!fo,po=fo=null,e.current=n,cd(n),Uc(),O=u,D=i,Ee.transition=o}else e.current=n;if(vr&&(vr=!1,tt=e,Zr=l),o=e.pendingLanes,o===0&&(ut=null),Vc(n.stateNode),pe(e,Q()),t!==null)for(r=e.onRecoverableError,n=0;n<t.length;n++)l=t[n],r(l.value,{componentStack:l.stack,digest:l.digest});if(Gr)throw Gr=!1,e=Do,Do=null,e;return Zr&1&&e.tag!==0&&Gt(),o=e.pendingLanes,o&1?e===Mo?Tn++:(Tn=0,Mo=e):Tn=0,mt(),null}function Gt(){if(tt!==null){var e=za(Zr),t=Ee.transition,n=D;try{if(Ee.transition=null,D=16>e?16:e,tt===null)var r=!1;else{if(e=tt,tt=null,Zr=0,O&6)throw Error(g(331));var l=O;for(O|=4,x=e.current;x!==null;){var o=x,i=o.child;if(x.flags&16){var u=o.deletions;if(u!==null){for(var a=0;a<u.length;a++){var c=u[a];for(x=c;x!==null;){var v=x;switch(v.tag){case 0:case 11:case 15:Pn(8,v,o)}var m=v.child;if(m!==null)m.return=v,x=m;else for(;x!==null;){v=x;var p=v.sibling,y=v.return;if(js(v),v===c){x=null;break}if(p!==null){p.return=y,x=p;break}x=y}}}var k=o.alternate;if(k!==null){var w=k.child;if(w!==null){k.child=null;do{var j=w.sibling;w.sibling=null,w=j}while(w!==null)}}x=o}}if(o.subtreeFlags&2064&&i!==null)i.return=o,x=i;else e:for(;x!==null;){if(o=x,o.flags&2048)switch(o.tag){case 0:case 11:case 15:Pn(9,o,o.return)}var f=o.sibling;if(f!==null){f.return=o.return,x=f;break e}x=o.return}}var s=e.current;for(x=s;x!==null;){i=x;var d=i.child;if(i.subtreeFlags&2064&&d!==null)d.return=i,x=d;else e:for(i=s;x!==null;){if(u=x,u.flags&2048)try{switch(u.tag){case 0:case 11:case 15:al(9,u)}}catch(S){V(u,u.return,S)}if(u===i){x=null;break e}var h=u.sibling;if(h!==null){h.return=u.return,x=h;break e}x=u.return}}if(O=l,mt(),je&&typeof je.onPostCommitFiberRoot=="function")try{je.onPostCommitFiberRoot(el,e)}catch{}r=!0}return r}finally{D=n,Ee.transition=t}}return!1}function ju(e,t,n){t=tn(n,t),t=zs(e,t,1),e=it(e,t,1),t=ie(),e!==null&&(Xn(e,1,t),pe(e,t))}function V(e,t,n){if(e.tag===3)ju(e,e,n);else for(;t!==null;){if(t.tag===3){ju(t,e,n);break}else if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof r.componentDidCatch=="function"&&(ut===null||!ut.has(r))){e=tn(n,e),e=Ps(t,e,1),t=it(t,e,1),e=ie(),t!==null&&(Xn(t,1,e),pe(t,e));break}}t=t.return}}function hd(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),t=ie(),e.pingedLanes|=e.suspendedLanes&n,J===e&&(b&n)===n&&(X===4||X===3&&(b&130023424)===b&&500>Q()-Si?St(e,0):xi|=n),pe(e,t)}function Ys(e,t){t===0&&(e.mode&1?(t=or,or<<=1,!(or&130023424)&&(or=4194304)):t=1);var n=ie();e=Ke(e,t),e!==null&&(Xn(e,t,n),pe(e,n))}function gd(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Ys(e,n)}function yd(e,t){var n=0;switch(e.tag){case 13:var r=e.stateNode,l=e.memoizedState;l!==null&&(n=l.retryLane);break;case 19:r=e.stateNode;break;default:throw Error(g(314))}r!==null&&r.delete(t),Ys(e,n)}var Xs;Xs=function(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps||fe.current)ce=!0;else{if(!(e.lanes&n)&&!(t.flags&128))return ce=!1,od(e,t,n);ce=!!(e.flags&131072)}else ce=!1,$&&t.flags&1048576&&qa(t,Br,t.index);switch(t.lanes=0,t.tag){case 2:var r=t.type;_r(e,t),e=t.pendingProps;var l=Jt(t,le.current);Xt(t,n),l=vi(null,t,r,e,l,n);var o=hi();return t.flags|=1,typeof l=="object"&&l!==null&&typeof l.render=="function"&&l.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,de(r)?(o=!0,Ur(t)):o=!1,t.memoizedState=l.state!==null&&l.state!==void 0?l.state:null,ci(t),l.updater=ul,t.stateNode=l,l._reactInternals=t,So(t,r,e,n),t=_o(null,t,r,!0,o,n)):(t.tag=0,$&&o&&ri(t),oe(null,t,l,n),t=t.child),t;case 16:r=t.elementType;e:{switch(_r(e,t),e=t.pendingProps,l=r._init,r=l(r._payload),t.type=r,l=t.tag=wd(r),e=Ne(r,e),l){case 0:t=Co(null,t,r,e,n);break e;case 1:t=Pu(null,t,r,e,n);break e;case 11:t=_u(null,t,r,e,n);break e;case 14:t=zu(null,t,r,Ne(r.type,e),n);break e}throw Error(g(306,r,""))}return t;case 0:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Ne(r,l),Co(e,t,r,l,n);case 1:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Ne(r,l),Pu(e,t,r,l,n);case 3:e:{if(Rs(t),e===null)throw Error(g(387));r=t.pendingProps,o=t.memoizedState,l=o.element,ls(e,t),Wr(t,r,null,n);var i=t.memoizedState;if(r=i.element,o.isDehydrated)if(o={element:r,isDehydrated:!1,cache:i.cache,pendingSuspenseBoundaries:i.pendingSuspenseBoundaries,transitions:i.transitions},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){l=tn(Error(g(423)),t),t=Nu(e,t,r,n,l);break e}else if(r!==l){l=tn(Error(g(424)),t),t=Nu(e,t,r,n,l);break e}else for(ve=ot(t.stateNode.containerInfo.firstChild),he=t,$=!0,Le=null,n=ns(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(qt(),r===l){t=Ye(e,t,n);break e}oe(e,t,r,n)}t=t.child}return t;case 5:return os(t),e===null&&ko(t),r=t.type,l=t.pendingProps,o=e!==null?e.memoizedProps:null,i=l.children,mo(r,l)?i=null:o!==null&&mo(r,o)&&(t.flags|=32),Ls(e,t),oe(e,t,i,n),t.child;case 6:return e===null&&ko(t),null;case 13:return Os(e,t,n);case 4:return fi(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=bt(t,null,r,n):oe(e,t,r,n),t.child;case 11:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Ne(r,l),_u(e,t,r,l,n);case 7:return oe(e,t,t.pendingProps,n),t.child;case 8:return oe(e,t,t.pendingProps.children,n),t.child;case 12:return oe(e,t,t.pendingProps.children,n),t.child;case 10:e:{if(r=t.type._context,l=t.pendingProps,o=t.memoizedProps,i=l.value,M(Vr,r._currentValue),r._currentValue=i,o!==null)if(De(o.value,i)){if(o.children===l.children&&!fe.current){t=Ye(e,t,n);break e}}else for(o=t.child,o!==null&&(o.return=t);o!==null;){var u=o.dependencies;if(u!==null){i=o.child;for(var a=u.firstContext;a!==null;){if(a.context===r){if(o.tag===1){a=He(-1,n&-n),a.tag=2;var c=o.updateQueue;if(c!==null){c=c.shared;var v=c.pending;v===null?a.next=a:(a.next=v.next,v.next=a),c.pending=a}}o.lanes|=n,a=o.alternate,a!==null&&(a.lanes|=n),wo(o.return,n,t),u.lanes|=n;break}a=a.next}}else if(o.tag===10)i=o.type===t.type?null:o.child;else if(o.tag===18){if(i=o.return,i===null)throw Error(g(341));i.lanes|=n,u=i.alternate,u!==null&&(u.lanes|=n),wo(i,n,t),i=o.sibling}else i=o.child;if(i!==null)i.return=o;else for(i=o;i!==null;){if(i===t){i=null;break}if(o=i.sibling,o!==null){o.return=i.return,i=o;break}i=i.return}o=i}oe(e,t,l.children,n),t=t.child}return t;case 9:return l=t.type,r=t.pendingProps.children,Xt(t,n),l=Ce(l),r=r(l),t.flags|=1,oe(e,t,r,n),t.child;case 14:return r=t.type,l=Ne(r,t.pendingProps),l=Ne(r.type,l),zu(e,t,r,l,n);case 15:return Ns(e,t,t.type,t.pendingProps,n);case 17:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Ne(r,l),_r(e,t),t.tag=1,de(r)?(e=!0,Ur(t)):e=!1,Xt(t,n),_s(t,r,l),So(t,r,l,n),_o(null,t,r,!0,e,n);case 19:return Ds(e,t,n);case 22:return Ts(e,t,n)}throw Error(g(156,t.tag))};function Gs(e,t){return Sa(e,t)}function kd(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Se(e,t,n,r){return new kd(e,t,n,r)}function zi(e){return e=e.prototype,!(!e||!e.isReactComponent)}function wd(e){if(typeof e=="function")return zi(e)?1:0;if(e!=null){if(e=e.$$typeof,e===Qo)return 11;if(e===Ko)return 14}return 2}function st(e,t){var n=e.alternate;return n===null?(n=Se(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&14680064,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function Nr(e,t,n,r,l,o){var i=2;if(r=e,typeof e=="function")zi(e)&&(i=1);else if(typeof e=="string")i=5;else e:switch(e){case Dt:return Et(n.children,l,o,t);case Wo:i=8,l|=8;break;case Ql:return e=Se(12,n,t,l|2),e.elementType=Ql,e.lanes=o,e;case Kl:return e=Se(13,n,t,l),e.elementType=Kl,e.lanes=o,e;case Yl:return e=Se(19,n,t,l),e.elementType=Yl,e.lanes=o,e;case oa:return cl(n,l,o,t);default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case ra:i=10;break e;case la:i=9;break e;case Qo:i=11;break e;case Ko:i=14;break e;case Ze:i=16,r=null;break e}throw Error(g(130,e==null?e:typeof e,""))}return t=Se(i,n,t,l),t.elementType=e,t.type=r,t.lanes=o,t}function Et(e,t,n,r){return e=Se(7,e,r,t),e.lanes=n,e}function cl(e,t,n,r){return e=Se(22,e,r,t),e.elementType=oa,e.lanes=n,e.stateNode={isHidden:!1},e}function Vl(e,t,n){return e=Se(6,e,null,t),e.lanes=n,e}function Hl(e,t,n){return t=Se(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function xd(e,t,n,r,l){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=El(0),this.expirationTimes=El(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=El(0),this.identifierPrefix=r,this.onRecoverableError=l,this.mutableSourceEagerHydrationData=null}function Pi(e,t,n,r,l,o,i,u,a){return e=new xd(e,t,n,u,a),t===1?(t=1,o===!0&&(t|=8)):t=0,o=Se(3,null,null,t),e.current=o,o.stateNode=e,o.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},ci(o),e}function Sd(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Ot,key:r==null?null:""+r,children:e,containerInfo:t,implementation:n}}function Zs(e){if(!e)return ft;e=e._reactInternals;e:{if(Lt(e)!==e||e.tag!==1)throw Error(g(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break e;case 1:if(de(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break e}}t=t.return}while(t!==null);throw Error(g(171))}if(e.tag===1){var n=e.type;if(de(n))return Za(e,n,t)}return t}function Js(e,t,n,r,l,o,i,u,a){return e=Pi(n,r,!0,e,l,o,i,u,a),e.context=Zs(null),n=e.current,r=ie(),l=at(n),o=He(r,l),o.callback=t??null,it(n,o,l),e.current.lanes=l,Xn(e,l,r),pe(e,r),e}function fl(e,t,n,r){var l=t.current,o=ie(),i=at(l);return n=Zs(n),t.context===null?t.context=n:t.pendingContext=n,t=He(o,i),t.payload={element:e},r=r===void 0?null:r,r!==null&&(t.callback=r),e=it(l,t,i),e!==null&&(Oe(e,l,i,o),Sr(e,l,i)),i}function qr(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function $u(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function Ni(e,t){$u(e,t),(e=e.alternate)&&$u(e,t)}function Ed(){return null}var qs=typeof reportError=="function"?reportError:function(e){console.error(e)};function Ti(e){this._internalRoot=e}dl.prototype.render=Ti.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(g(409));fl(e,t,null,null)};dl.prototype.unmount=Ti.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Nt(function(){fl(null,e,null,null)}),t[Qe]=null}};function dl(e){this._internalRoot=e}dl.prototype.unstable_scheduleHydration=function(e){if(e){var t=Ta();e={blockedOn:null,target:e,priority:t};for(var n=0;n<qe.length&&t!==0&&t<qe[n].priority;n++);qe.splice(n,0,e),n===0&&Ra(e)}};function Li(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function pl(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==" react-mount-point-unstable "))}function Uu(){}function Cd(e,t,n,r,l){if(l){if(typeof r=="function"){var o=r;r=function(){var c=qr(i);o.call(c)}}var i=Js(t,r,e,0,null,!1,!1,"",Uu);return e._reactRootContainer=i,e[Qe]=i.current,$n(e.nodeType===8?e.parentNode:e),Nt(),i}for(;l=e.lastChild;)e.removeChild(l);if(typeof r=="function"){var u=r;r=function(){var c=qr(a);u.call(c)}}var a=Pi(e,0,!1,null,null,!1,!1,"",Uu);return e._reactRootContainer=a,e[Qe]=a.current,$n(e.nodeType===8?e.parentNode:e),Nt(function(){fl(t,a,n,r)}),a}function ml(e,t,n,r,l){var o=n._reactRootContainer;if(o){var i=o;if(typeof l=="function"){var u=l;l=function(){var a=qr(i);u.call(a)}}fl(t,i,e,l)}else i=Cd(n,t,e,l,r);return qr(i)}Pa=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var n=kn(t.pendingLanes);n!==0&&(Go(t,n|1),pe(t,Q()),!(O&6)&&(nn=Q()+500,mt()))}break;case 13:Nt(function(){var r=Ke(e,1);if(r!==null){var l=ie();Oe(r,e,1,l)}}),Ni(e,1)}};Zo=function(e){if(e.tag===13){var t=Ke(e,134217728);if(t!==null){var n=ie();Oe(t,e,134217728,n)}Ni(e,134217728)}};Na=function(e){if(e.tag===13){var t=at(e),n=Ke(e,t);if(n!==null){var r=ie();Oe(n,e,t,r)}Ni(e,t)}};Ta=function(){return D};La=function(e,t){var n=D;try{return D=e,t()}finally{D=n}};ro=function(e,t,n){switch(t){case"input":if(Zl(e,n),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+t)+'][type="radio"]'),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var l=ll(r);if(!l)throw Error(g(90));ua(r),Zl(r,l)}}}break;case"textarea":sa(e,n);break;case"select":t=n.value,t!=null&&Wt(e,!!n.multiple,t,!1)}};ha=Ei;ga=Nt;var _d={usingClientEntryPoint:!1,Events:[Zn,jt,ll,ma,va,Ei]},hn={findFiberByHostInstance:kt,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},zd={bundleType:hn.bundleType,version:hn.version,rendererPackageName:hn.rendererPackageName,rendererConfig:hn.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Xe.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=wa(e),e===null?null:e.stateNode},findFiberByHostInstance:hn.findFiberByHostInstance||Ed,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var hr=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!hr.isDisabled&&hr.supportsFiber)try{el=hr.inject(zd),je=hr}catch{}}ye.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=_d;ye.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!Li(t))throw Error(g(200));return Sd(e,t,null,n)};ye.createRoot=function(e,t){if(!Li(e))throw Error(g(299));var n=!1,r="",l=qs;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onRecoverableError!==void 0&&(l=t.onRecoverableError)),t=Pi(e,1,!1,null,null,n,!1,r,l),e[Qe]=t.current,$n(e.nodeType===8?e.parentNode:e),new Ti(t)};ye.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(g(188)):(e=Object.keys(e).join(","),Error(g(268,e)));return e=wa(t),e=e===null?null:e.stateNode,e};ye.flushSync=function(e){return Nt(e)};ye.hydrate=function(e,t,n){if(!pl(t))throw Error(g(200));return ml(null,e,t,!0,n)};ye.hydrateRoot=function(e,t,n){if(!Li(e))throw Error(g(405));var r=n!=null&&n.hydratedSources||null,l=!1,o="",i=qs;if(n!=null&&(n.unstable_strictMode===!0&&(l=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onRecoverableError!==void 0&&(i=n.onRecoverableError)),t=Js(t,null,e,1,n??null,l,!1,o,i),e[Qe]=t.current,$n(e),r)for(e=0;e<r.length;e++)n=r[e],l=n._getVersion,l=l(n._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[n,l]:t.mutableSourceEagerHydrationData.push(n,l);return new dl(t)};ye.render=function(e,t,n){if(!pl(t))throw Error(g(200));return ml(null,e,t,!1,n)};ye.unmountComponentAtNode=function(e){if(!pl(e))throw Error(g(40));return e._reactRootContainer?(Nt(function(){ml(null,null,e,!1,function(){e._reactRootContainer=null,e[Qe]=null})}),!0):!1};ye.unstable_batchedUpdates=Ei;ye.unstable_renderSubtreeIntoContainer=function(e,t,n,r){if(!pl(n))throw Error(g(200));if(e==null||e._reactInternals===void 0)throw Error(g(38));return ml(e,t,n,!1,r)};ye.version="18.3.1-next-f1338f8080-20240426";function bs(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(bs)}catch(e){console.error(e)}}bs(),bu.exports=ye;var Pd=bu.exports,Nd,Au=Pd;Nd=Au.createRoot,Au.hydrateRoot;const L="cubic-bezier(0.32, 0.72, 0, 1)",Td=`
:host, * { box-sizing: border-box; }

.ktm {
  /* ── Superfícies ─────────────────────────────────────────────────────── */
  --casca:        rgba(20, 20, 24, 0.78);
  --corpo:        #0B0B0E;
  --nucleo:       #131318;
  --nucleo-alto:  #191920;
  --fio:          rgba(255, 255, 255, 0.07);
  --fio-forte:    rgba(255, 255, 255, 0.12);
  --brilho:       inset 0 1px 0 rgba(255, 255, 255, 0.06);

  /* ── Tinta ───────────────────────────────────────────────────────────── */
  --ink:          #F2F2F5;
  --ink-2:        rgba(242, 242, 245, 0.64);
  --ink-3:        rgba(242, 242, 245, 0.40);

  /* ── Semântica (calibrada para fundo escuro) ─────────────────────────── */
  --marca:        #E14B52;
  --verde:        #46D68F;   --verde-bg:    rgba(70, 214, 143, 0.13);
  --ambar:        #F5B544;   --ambar-bg:    rgba(245, 181, 68, 0.13);
  --vermelho:     #FF7070;   --vermelho-bg: rgba(255, 112, 112, 0.13);
  --azul:         #86A8FF;   --azul-bg:     rgba(134, 168, 255, 0.13);

  --raio-casca:   26px;
  --raio-nucleo:  20px;

  position: fixed;
  top: 64px;
  left: 16px;
  width: 392px;
  max-height: calc(100vh - 96px);
  z-index: 2147483647;

  display: flex;
  flex-direction: column;
  overflow: hidden;

  padding: 6px;
  border-radius: var(--raio-casca);
  border: 1px solid var(--fio);
  background: var(--casca);
  backdrop-filter: blur(28px) saturate(180%);
  -webkit-backdrop-filter: blur(28px) saturate(180%);
  box-shadow:
    0 32px 80px -24px rgba(0, 0, 0, 0.72),
    0 2px 8px rgba(0, 0, 0, 0.28),
    var(--brilho);

  color: var(--ink);
  font-family: ui-sans-serif, -apple-system, "SF Pro Text", "Segoe UI Variable Text",
               "Segoe UI", system-ui, sans-serif;
  font-size: 13px;
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
  font-variant-numeric: tabular-nums;
}

/* Duas auroras discretas atrás do topo — dão profundidade sem virar "gradiente". */
.ktm::before {
  content: '';
  position: absolute;
  inset: -40% -30% auto -30%;
  height: 320px;
  pointer-events: none;
  background:
    radial-gradient(46% 46% at 22% 34%, rgba(225, 75, 82, 0.20), transparent 70%),
    radial-gradient(40% 40% at 80% 20%, rgba(122, 140, 255, 0.16), transparent 70%);
  filter: blur(24px);
  opacity: 0.9;
}

/* ── Núcleo: o miolo escuro dentro da casca ───────────────────────────── */
.ktm-nucleo {
  position: relative;
  display: flex;
  flex-direction: column;
  min-height: 0;
  border-radius: var(--raio-nucleo);
  background: var(--corpo);
  border: 1px solid var(--fio);
  overflow: hidden;
}

/* ── Cabeçalho ────────────────────────────────────────────────────────── */
.ktm-topo {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 12px 13px 11px;
  border-bottom: 1px solid var(--fio);
  background: linear-gradient(180deg, rgba(255,255,255,0.045), transparent);
}

.ktm-marca {
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
}

.ktm-selo {
  width: 22px; height: 22px;
  flex-shrink: 0;
  border-radius: 8px;
  display: grid;
  place-items: center;
  font-size: 11px;
  font-weight: 650;
  letter-spacing: -0.02em;
  color: #fff;
  background: linear-gradient(150deg, var(--marca), #A62830);
  box-shadow: 0 3px 10px -3px rgba(225, 75, 82, 0.7), var(--brilho);
}

.ktm-marca-txt {
  font-size: 10.5px;
  font-weight: 600;
  letter-spacing: 0.16em;
  text-transform: uppercase;
  color: var(--ink-2);
  white-space: nowrap;
}

.ktm-icone-btn {
  width: 26px; height: 26px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  border: 1px solid transparent;
  border-radius: 9px;
  background: transparent;
  color: var(--ink-3);
  cursor: pointer;
  font-size: 14px;
  line-height: 1;
  font-family: inherit;
  transition: color 400ms ${L}, background 400ms ${L}, border-color 400ms ${L};
}
.ktm-icone-btn:hover {
  color: var(--ink);
  background: rgba(255, 255, 255, 0.06);
  border-color: var(--fio);
}

/* ── Identidade (nome + contatos copiáveis) ───────────────────────────── */
.ktm-id {
  padding: 13px 13px 12px;
  border-bottom: 1px solid var(--fio);
}

.ktm-id-nome {
  display: flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
}

.ktm-nome {
  font-size: 16.5px;
  font-weight: 620;
  letter-spacing: -0.022em;
  color: var(--ink);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.ktm-contatos {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  margin-top: 8px;
}

/* Pílula de contato: o texto é o botão de copiar. */
.ktm-copia {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  padding: 4px 5px 4px 9px;
  border: 1px solid var(--fio);
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.035);
  color: var(--ink-2);
  font: inherit;
  font-size: 11px;
  cursor: pointer;
  transition: transform 500ms ${L}, background 500ms ${L},
              border-color 500ms ${L}, color 500ms ${L};
}
.ktm-copia:hover {
  background: rgba(255, 255, 255, 0.08);
  border-color: var(--fio-forte);
  color: var(--ink);
}
.ktm-copia:active { transform: scale(0.97); }
.ktm-copia--ok    { color: var(--verde); border-color: rgba(70, 214, 143, 0.4); background: var(--verde-bg); }
.ktm-copia--erro  { color: var(--vermelho); border-color: rgba(255, 112, 112, 0.4); }

.ktm-copia-txt {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* Ícone dentro do seu próprio círculo, encostado na borda interna da pílula. */
.ktm-copia-icone {
  width: 20px; height: 20px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.07);
  transition: transform 500ms ${L}, background 500ms ${L};
}
.ktm-copia:hover .ktm-copia-icone {
  background: rgba(255, 255, 255, 0.13);
  transform: translateY(-1px) scale(1.06);
}
.ktm-copia-icone svg { width: 11px; height: 11px; display: block; }

.ktm-wpp {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  border-radius: 999px;
  border: 1px solid rgba(70, 214, 143, 0.28);
  background: var(--verde-bg);
  color: var(--verde);
  font-size: 11px;
  font-weight: 550;
  text-decoration: none;
  white-space: nowrap;
  transition: transform 500ms ${L}, background 500ms ${L};
}
.ktm-wpp:hover { background: rgba(70, 214, 143, 0.2); transform: translateY(-1px); }

/* Copiar o nome: fica no próprio título, sem repetir o nome numa pílula. */
.ktm-nome-copia {
  width: 24px; height: 24px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  padding: 0;
  border: 1px solid var(--fio);
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.04);
  color: var(--ink-3);
  cursor: pointer;
  transition: all 450ms ${L};
}
.ktm-nome-copia:hover  { color: var(--ink); background: rgba(255,255,255,0.1); border-color: var(--fio-forte); }
.ktm-nome-copia:active { transform: scale(0.94); }
.ktm-nome-copia--ok    { color: var(--verde); border-color: rgba(70,214,143,0.4); background: var(--verde-bg); }
.ktm-nome-copia svg    { width: 12px; height: 12px; display: block; }

/* ── Abas ─────────────────────────────────────────────────────────────── */
.ktm-abas {
  position: relative;
  display: flex;
  gap: 1px;
  padding: 7px 6px 0;
  border-bottom: 1px solid var(--fio);
  overflow-x: auto;
  scrollbar-width: none;
}
/* Esmaece a última aba em vez de cortá-la em seco — só quando a fileira REALMENTE
   rola, senão a última aba viveria apagada à toa (a classe vem medida do React). */
.ktm-abas--rola {
  -webkit-mask-image: linear-gradient(90deg, #000 calc(100% - 22px), transparent);
          mask-image: linear-gradient(90deg, #000 calc(100% - 22px), transparent);
}
.ktm-abas::-webkit-scrollbar { display: none; }

.ktm-aba {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex-shrink: 0;
  padding: 7px 8px 9px;
  border: 0;
  background: transparent;
  color: var(--ink-3);
  font: inherit;
  font-size: 11px;
  font-weight: 550;
  letter-spacing: -0.01em;
  cursor: pointer;
  transition: color 450ms ${L};
}
.ktm-aba:hover { color: var(--ink-2); }
.ktm-aba--on   { color: var(--ink); }

/* Sublinhado que corre entre as abas em vez de piscar. */
.ktm-aba::after {
  content: '';
  position: absolute;
  left: 6px; right: 6px; bottom: -1px;
  height: 2px;
  border-radius: 2px;
  background: var(--marca);
  transform: scaleX(0);
  transform-origin: center;
  transition: transform 550ms ${L};
}
.ktm-aba--on::after { transform: scaleX(1); }

.ktm-aba-n {
  min-width: 16px;
  padding: 0 4px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.09);
  font-size: 9.5px;
  font-weight: 650;
  line-height: 16px;
  text-align: center;
  color: var(--ink-2);
}
.ktm-aba-n--alerta { background: var(--vermelho-bg); color: var(--vermelho); }

/* ── Corpo rolável ────────────────────────────────────────────────────── */
.ktm-corpo {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  overflow-anchor: none;
  padding: 12px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.ktm-corpo::-webkit-scrollbar { width: 8px; }
.ktm-corpo::-webkit-scrollbar-thumb {
  border: 2px solid transparent;
  background-clip: padding-box;
  border-radius: 99px;
  background-color: rgba(255, 255, 255, 0.12);
}
.ktm-corpo::-webkit-scrollbar-thumb:hover { background-color: rgba(255, 255, 255, 0.22); }

/* ── Cartão ───────────────────────────────────────────────────────────── */
.ktm-cartao {
  position: relative;
  padding: 12px 13px;
  border-radius: 16px;
  background: var(--nucleo);
  border: 1px solid var(--fio);
  box-shadow: var(--brilho);
}
.ktm-cartao--destaque { background: var(--nucleo-alto); }

.ktm-cartao-topo {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 9px;
}

.ktm-rotulo {
  font-size: 9.5px;
  font-weight: 650;
  letter-spacing: 0.13em;
  text-transform: uppercase;
  color: var(--ink-3);
}

/* Bento: cartões de tamanhos diferentes na mesma grade. */
.ktm-bento {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}
.ktm-bento > .ktm-largo { grid-column: span 2; }

.ktm-fato {
  padding: 10px 11px;
  border-radius: 14px;
  background: var(--nucleo);
  border: 1px solid var(--fio);
  box-shadow: var(--brilho);
  min-width: 0;
}
.ktm-fato-k {
  font-size: 9.5px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--ink-3);
}
.ktm-fato-v {
  margin-top: 3px;
  font-size: 13px;
  font-weight: 550;
  color: var(--ink);
  letter-spacing: -0.012em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

/* ── Selos ────────────────────────────────────────────────────────────── */
.ktm-selo-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 8px;
  border-radius: 999px;
  border: 1px solid var(--fio);
  background: rgba(255, 255, 255, 0.05);
  color: var(--ink-2);
  font-size: 10.5px;
  font-weight: 550;
  white-space: nowrap;
}
.ktm-selo-chip--verde    { color: var(--verde);    background: var(--verde-bg);    border-color: rgba(70, 214, 143, 0.22); }
.ktm-selo-chip--ambar    { color: var(--ambar);    background: var(--ambar-bg);    border-color: rgba(245, 181, 68, 0.22); }
.ktm-selo-chip--vermelho { color: var(--vermelho); background: var(--vermelho-bg); border-color: rgba(255, 112, 112, 0.22); }
.ktm-selo-chip--azul     { color: var(--azul);     background: var(--azul-bg);     border-color: rgba(134, 168, 255, 0.22); }

.ktm-chips { display: flex; flex-wrap: wrap; gap: 5px; }

/* ── Botões ───────────────────────────────────────────────────────────── */
.ktm-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 9px 14px;
  border-radius: 999px;
  border: 1px solid var(--fio-forte);
  background: rgba(255, 255, 255, 0.06);
  color: var(--ink);
  font: inherit;
  font-size: 12.5px;
  font-weight: 550;
  cursor: pointer;
  transition: transform 450ms ${L}, background 450ms ${L}, border-color 450ms ${L};
}
.ktm-btn:hover:not(:disabled) { background: rgba(255, 255, 255, 0.11); border-color: rgba(255,255,255,0.2); }
.ktm-btn:active:not(:disabled) { transform: scale(0.975); }
.ktm-btn:disabled { opacity: 0.4; cursor: default; }
.ktm-btn--bloco { width: 100%; }

.ktm-btn--principal {
  background: var(--ink);
  border-color: transparent;
  color: #0B0B0E;
  padding-right: 5px;
}
.ktm-btn--principal:hover:not(:disabled) { background: #fff; }

.ktm-btn--ok {
  background: var(--verde-bg);
  border-color: rgba(70, 214, 143, 0.3);
  color: var(--verde);
}
.ktm-btn--ok:hover:not(:disabled) { background: rgba(70, 214, 143, 0.2); }

.ktm-btn--perigo {
  background: var(--vermelho-bg);
  border-color: rgba(255, 112, 112, 0.32);
  color: var(--vermelho);
}
.ktm-btn--perigo:hover:not(:disabled) { background: rgba(255, 112, 112, 0.2); }

/* Ícone no seu próprio círculo, encostado na borda interna do botão. */
.ktm-btn-icone {
  width: 26px; height: 26px;
  display: grid;
  place-items: center;
  border-radius: 999px;
  background: rgba(0, 0, 0, 0.08);
  transition: transform 450ms ${L}, background 450ms ${L};
}
.ktm-btn--principal:hover .ktm-btn-icone {
  background: rgba(0, 0, 0, 0.14);
  transform: translate(2px, -1px) scale(1.05);
}
.ktm-btn-icone svg { width: 12px; height: 12px; display: block; }

.ktm-linkbtn {
  padding: 0;
  border: 0;
  background: none;
  color: var(--ink-2);
  font: inherit;
  font-size: 11.5px;
  font-weight: 550;
  cursor: pointer;
  transition: color 400ms ${L};
}
.ktm-linkbtn:hover:not(:disabled) { color: var(--ink); }
.ktm-linkbtn:disabled { opacity: 0.45; cursor: default; }

.ktm-acoes { display: flex; gap: 7px; margin-top: 9px; }
.ktm-acoes > * { flex: 1; }

/* ── Campos ───────────────────────────────────────────────────────────── */
.ktm-campo,
.ktm-area,
.ktm-select {
  width: 100%;
  padding: 9px 11px;
  border-radius: 12px;
  border: 1px solid var(--fio);
  background: rgba(255, 255, 255, 0.04);
  color: var(--ink);
  font: inherit;
  font-size: 12.5px;
  outline: none;
  transition: border-color 400ms ${L}, background 400ms ${L}, box-shadow 400ms ${L};
}
.ktm-campo::placeholder, .ktm-area::placeholder { color: var(--ink-3); }
.ktm-campo:focus, .ktm-area:focus, .ktm-select:focus {
  border-color: rgba(225, 75, 82, 0.45);
  background: rgba(255, 255, 255, 0.06);
  box-shadow: 0 0 0 3px rgba(225, 75, 82, 0.12);
}
.ktm-area { min-height: 62px; resize: vertical; }
.ktm-select { appearance: none; cursor: pointer; }
.ktm-select option { background: #17171C; color: var(--ink); }

/* Escolha em pílulas (natureza, urgência, tipo). */
.ktm-opcoes { display: flex; flex-wrap: wrap; gap: 5px; }
.ktm-opcao {
  padding: 5px 11px;
  border-radius: 999px;
  border: 1px solid var(--fio);
  background: transparent;
  color: var(--ink-3);
  font: inherit;
  font-size: 11.5px;
  font-weight: 550;
  cursor: pointer;
  transition: all 450ms ${L};
}
.ktm-opcao:hover { color: var(--ink-2); border-color: var(--fio-forte); }
.ktm-opcao--on {
  color: #0B0B0E;
  background: var(--ink);
  border-color: transparent;
}

/* ── Listas ───────────────────────────────────────────────────────────── */
.ktm-lista { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; }
.ktm-lista--esp { gap: 9px; }

.ktm-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 8px 0;
  border-top: 1px solid var(--fio);
  min-width: 0;
}
.ktm-lista > .ktm-item:first-child { border-top: 0; padding-top: 2px; }

.ktm-item-nome {
  font-size: 12.5px;
  color: var(--ink);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
}
.ktm-item-meta { font-size: 10.5px; color: var(--ink-3); white-space: nowrap; flex-shrink: 0; }

/* Registro com filete colorido à esquerda (incidente / observação). */
.ktm-registro {
  padding: 9px 0 9px 11px;
  border-left: 2px solid var(--fio-forte);
  border-radius: 2px;
}
.ktm-registro--alta   { border-left-color: var(--ambar); }
.ktm-registro--critica{ border-left-color: var(--vermelho); }
.ktm-registro-topo {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--ink-3);
}
.ktm-registro-txt { margin: 4px 0 0; font-size: 12.5px; color: var(--ink); line-height: 1.5; }

.ktm-txt   { font-size: 12.5px; color: var(--ink); line-height: 1.5; margin: 0; }
.ktm-txt-2 { font-size: 11.5px; color: var(--ink-2); line-height: 1.5; margin: 0; }
.ktm-txt-3 { font-size: 10.5px; color: var(--ink-3); line-height: 1.5; margin: 0; }
.ktm-erro  { font-size: 11.5px; color: var(--vermelho); margin: 8px 0 0; }

.ktm-vazio {
  padding: 26px 14px;
  text-align: center;
  font-size: 12px;
  color: var(--ink-3);
  line-height: 1.6;
}

/* ── Números grandes ──────────────────────────────────────────────────── */
.ktm-numero {
  font-size: 30px;
  font-weight: 600;
  letter-spacing: -0.045em;
  line-height: 1;
  color: var(--ink);
}
.ktm-delta { display: flex; align-items: baseline; gap: 8px; flex-wrap: wrap; }

/* ── Barras (distribuição de estrelas / positivos-negativos) ──────────── */
.ktm-barra {
  height: 5px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.07);
  overflow: hidden;
  flex: 1;
}
.ktm-barra > i {
  display: block;
  height: 100%;
  border-radius: 999px;
  transform-origin: left;
  animation: ktm-barra 900ms ${L} both;
}
@keyframes ktm-barra { from { transform: scaleX(0); } to { transform: scaleX(1); } }

.ktm-split { display: flex; height: 6px; border-radius: 999px; overflow: hidden; background: rgba(255,255,255,0.07); }
.ktm-split > i { display: block; height: 100%; }

/* ── Ranking da reunião em grupo ──────────────────────────────────────── */
.ktm-rank {
  display: block;
  width: 100%;
  padding: 9px 10px;
  border: 1px solid var(--fio);
  border-radius: 13px;
  background: var(--nucleo);
  color: var(--ink);
  font: inherit;
  text-align: left;
  cursor: pointer;
  transition: transform 450ms ${L}, background 450ms ${L}, border-color 450ms ${L};
}
.ktm-rank:hover { background: var(--nucleo-alto); border-color: var(--fio-forte); transform: translateX(2px); }

/* Os três primeiros ganham um filete à esquerda — pódio sem virar medalha. */
.ktm-rank--1 { border-left: 2px solid var(--verde); }
.ktm-rank--2 { border-left: 2px solid rgba(70, 214, 143, 0.5); }
.ktm-rank--3 { border-left: 2px solid rgba(70, 214, 143, 0.28); }
.ktm-rank--ultimo { border-left: 2px solid var(--vermelho); }

.ktm-rank-topo { display: flex; align-items: center; gap: 8px; min-width: 0; }

.ktm-rank-pos {
  width: 20px; height: 20px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.07);
  font-size: 10px;
  font-weight: 650;
  color: var(--ink-2);
}
.ktm-rank--1 .ktm-rank-pos { background: var(--verde); color: #08130D; }

.ktm-rank-nome {
  flex: 1;
  min-width: 0;
  font-size: 12.5px;
  font-weight: 550;
  letter-spacing: -0.01em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ktm-rank-pts {
  flex-shrink: 0;
  font-size: 13px;
  font-weight: 650;
  letter-spacing: -0.02em;
}

.ktm-rank-barra {
  height: 3px;
  margin: 7px 0 6px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.07);
  overflow: hidden;
}
.ktm-rank-barra > i {
  display: block;
  height: 100%;
  border-radius: 999px;
  transform-origin: left;
  animation: ktm-barra 900ms ${L} both;
}

.ktm-rank-metricas {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 10px;
  font-size: 10.5px;
  color: var(--ink-3);
}
.ktm-rank-metricas b { color: var(--ink-2); font-weight: 600; }

/* Detalhe dos eixos (o "por quê" da posição). */
.ktm-eixo {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  font-size: 11px;
  padding: 3px 0;
}
.ktm-eixo-n { font-variant-numeric: tabular-nums; font-weight: 600; flex-shrink: 0; }

/* ── Caixa de presença (reunião em grupo) ─────────────────────────────── */
.ktm-check {
  width: 22px; height: 22px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  padding: 0;
  border-radius: 7px;
  border: 1px solid var(--fio-forte);
  background: transparent;
  color: transparent;
  cursor: pointer;
  transition: all 450ms ${L};
}
.ktm-check:hover { border-color: rgba(70, 214, 143, 0.5); }
.ktm-check svg { width: 13px; height: 13px; display: block; }
.ktm-check--on {
  background: var(--verde);
  border-color: var(--verde);
  color: #08130D;
}

/* ── Sugestões de busca ───────────────────────────────────────────────── */
.ktm-sugestao {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  width: 100%;
  padding: 10px 12px;
  border-radius: 14px;
  border: 1px solid var(--fio);
  background: var(--nucleo);
  color: var(--ink);
  font: inherit;
  font-size: 12.5px;
  font-weight: 550;
  text-align: left;
  cursor: pointer;
  transition: transform 450ms ${L}, background 450ms ${L}, border-color 450ms ${L};
}
.ktm-sugestao:hover { background: var(--nucleo-alto); border-color: var(--fio-forte); transform: translateX(2px); }

/* ── Entrada em cena (nada aparece parado) ────────────────────────────── */
.ktm-entra {
  animation: ktm-sobe 700ms ${L} both;
  animation-delay: var(--atraso, 0ms);
}
@keyframes ktm-sobe {
  from { opacity: 0; transform: translate3d(0, 14px, 0); filter: blur(5px); }
  to   { opacity: 1; transform: translate3d(0, 0, 0);    filter: blur(0); }
}

/* ── Botão flutuante (painel minimizado) ──────────────────────────────── */
.ktm-fab {
  position: fixed;
  top: 64px;
  left: 16px;
  z-index: 2147483647;
  width: 46px; height: 46px;
  display: grid;
  place-items: center;
  padding: 0;
  border-radius: 16px;
  border: 1px solid var(--fio, rgba(255,255,255,0.07));
  background: rgba(20, 20, 24, 0.78);
  backdrop-filter: blur(24px) saturate(180%);
  -webkit-backdrop-filter: blur(24px) saturate(180%);
  box-shadow: 0 18px 40px -16px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.07);
  cursor: pointer;
  transition: transform 550ms ${L}, box-shadow 550ms ${L};
}
.ktm-fab::before { content: none; }  /* a aurora é do painel, não do botão */
.ktm-fab:hover  { transform: translateY(-2px) scale(1.04); box-shadow: 0 24px 50px -16px rgba(0,0,0,0.8); }
.ktm-fab:active { transform: scale(0.96); }

@media (prefers-reduced-motion: reduce) {
  .ktm *, .ktm::before { animation-duration: 1ms !important; transition-duration: 1ms !important; }
  .ktm-entra { animation: none; }
}
`;function Rd(e){if(e.querySelector("style[data-ktm]"))return;const t=document.createElement("style");t.setAttribute("data-ktm",""),t.textContent=Td,e.appendChild(t)}export{Td as C,Nd as c,Rd as i,Ld as j,Ju as r};
